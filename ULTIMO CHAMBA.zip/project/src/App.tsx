import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import PageNotFound from '@/lib/PageNotFound';
import Login from '@/pages/Login';
import Home from '@/pages/Home';
import WorkerProfile from '@/pages/WorkerProfile';
import Chat from '@/pages/Chat';
import Settings from '@/pages/Settings';
import Jobs from '@/pages/Jobs';
import HireWorker from '@/pages/HireWorker';
import WorkerDashboard from '@/pages/WorkerDashboard';
import RolePicker from '@/components/chamba/RolePicker';

function AuthenticatedApp() {
  const { user, isLoading, needsRoleSelection } = useAuth();

  if (isLoading) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-background">
        <div className="text-center">
          <div className="w-10 h-10 border-4 border-muted border-t-primary rounded-full animate-spin mx-auto mb-3"></div>
          <p className="text-sm text-muted-foreground font-medium">Cargando...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <Login />;
  }

  // New user — must pick a role before entering the app
  if (needsRoleSelection) {
    return <RolePicker />;
  }

  return (
    <Routes>
      <Route path="/" element={<Navigate to="/Home" replace />} />
      <Route path="/Home" element={<Home />} />
      <Route path="/WorkerProfile" element={<WorkerProfile />} />
      <Route path="/Chat" element={<Chat />} />
      <Route path="/Settings" element={<Settings />} />
      <Route path="/Jobs" element={<Jobs />} />
      <Route path="/HireWorker" element={<HireWorker />} />
      <Route path="/WorkerDashboard" element={<WorkerDashboard />} />
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
}

function App() {
  return (
    <AuthProvider>
      <Router>
        <AuthenticatedApp />
      </Router>
    </AuthProvider>
  );
}

export default App;
