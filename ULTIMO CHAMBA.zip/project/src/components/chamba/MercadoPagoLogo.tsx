// Official MercadoPago brand color: #009EE3
export default function MercadoPagoLogo({ className = 'w-5 h-5' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect width="24" height="24" rx="6" fill="#009EE3" />
      <path
        d="M4 12C4 7.582 7.582 4 12 4s8 3.582 8 8-3.582 8-8 8-8-3.582-8-8z"
        fill="#009EE3"
      />
      <path
        d="M12 4C7.582 4 4 7.582 4 12s3.582 8 8 8 8-3.582 8-8-3.582-8-8-8zm0 1.5a6.5 6.5 0 1 1 0 13 6.5 6.5 0 0 1 0-13z"
        fill="white"
        opacity="0.3"
      />
      <text
        x="12"
        y="15.5"
        textAnchor="middle"
        fontSize="9"
        fontWeight="900"
        fontFamily="Arial, sans-serif"
        fill="white"
        letterSpacing="-0.5"
      >
        MP
      </text>
    </svg>
  );
}
