import { useState } from 'react';
import { Search, Wrench, ArrowRight, Loader2, CheckCircle } from 'lucide-react';
import { useAuth } from '@/lib/AuthContext';

export default function RolePicker() {
  const { profile, completeRoleSelection } = useAuth();
  const [loading, setLoading] = useState<'client' | 'worker' | null>(null);

  const pick = async (role: 'client' | 'worker') => {
    setLoading(role);
    await completeRoleSelection(role);
    // AuthContext clears needsRoleSelection → App.tsx renders the authenticated routes
  };

  const firstName = profile?.full_name?.split(' ')[0] ?? 'allá';

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4">
      <div className="flex items-center justify-center gap-3 mb-8">
        <img src="/Gemini_Generated_Image_qvyypfqvyypfqvyy.png" alt="Chamba" className="h-20 w-auto object-contain" />
        <img src="/Gemini_Generated_Image_jhvq6ujhvq6ujhvq.png" alt="Chamba" className="h-14 w-auto object-contain" />
      </div>

      <div className="w-full max-w-md">
        <div className="bg-card rounded-3xl border border-border card-shadow-lg p-6">
          <div className="text-center mb-6">
            <div className="w-14 h-14 gradient-brand rounded-2xl flex items-center justify-center mx-auto mb-4 glow-primary">
              <CheckCircle className="w-7 h-7 text-white" />
            </div>
            <h2 className="text-xl font-black text-foreground">
              ¡Bienvenido{firstName !== 'allá' ? `, ${firstName}` : ''}!
            </h2>
            <p className="text-sm text-muted-foreground mt-1">
              ¿Cómo vas a usar Chamba?
            </p>
          </div>

          <div className="space-y-3">
            {/* Contratar */}
            <button
              onClick={() => pick('client')}
              disabled={loading !== null}
              className="w-full group bg-muted hover:bg-accent border-2 border-border hover:border-primary/40 rounded-2xl p-5 text-left transition-all active:scale-[0.98] disabled:opacity-60"
            >
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 gradient-orange rounded-2xl flex items-center justify-center flex-shrink-0 shadow-lg group-hover:scale-105 transition-transform">
                  {loading === 'client'
                    ? <Loader2 className="w-7 h-7 text-white animate-spin" />
                    : <Search className="w-7 h-7 text-white" />
                  }
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-black text-foreground text-base">Quiero contratar</p>
                  <p className="text-sm text-muted-foreground mt-0.5">
                    Busco profesionales para mis proyectos
                  </p>
                  <div className="flex flex-wrap gap-1.5 mt-2">
                    {['Plomero', 'Electricista', 'Pintor'].map((tag) => (
                      <span key={tag} className="text-[10px] font-bold bg-secondary/15 text-secondary px-2 py-0.5 rounded-full">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
                <ArrowRight className="w-5 h-5 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all flex-shrink-0" />
              </div>
            </button>

            {/* Trabajador */}
            <button
              onClick={() => pick('worker')}
              disabled={loading !== null}
              className="w-full group bg-muted hover:bg-accent border-2 border-border hover:border-primary/40 rounded-2xl p-5 text-left transition-all active:scale-[0.98] disabled:opacity-60"
            >
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 gradient-brand rounded-2xl flex items-center justify-center flex-shrink-0 shadow-lg group-hover:scale-105 transition-transform">
                  {loading === 'worker'
                    ? <Loader2 className="w-7 h-7 text-white animate-spin" />
                    : <Wrench className="w-7 h-7 text-white" />
                  }
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-black text-foreground text-base">Quiero ofrecer mis servicios</p>
                  <p className="text-sm text-muted-foreground mt-0.5">
                    Soy profesional y quiero conseguir clientes
                  </p>
                  <div className="flex flex-wrap gap-1.5 mt-2">
                    {['Recibir trabajos', 'Fijar precios', 'Cobrar seguro'].map((tag) => (
                      <span key={tag} className="text-[10px] font-bold bg-primary/15 text-primary px-2 py-0.5 rounded-full">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
                <ArrowRight className="w-5 h-5 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all flex-shrink-0" />
              </div>
            </button>
          </div>

          <p className="text-center text-xs text-muted-foreground mt-5">
            Podés cambiar esto en cualquier momento desde Ajustes
          </p>
        </div>
      </div>
    </div>
  );
}
