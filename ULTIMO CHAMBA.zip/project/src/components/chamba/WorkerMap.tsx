import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import { Icon } from 'leaflet';
import { getWorkerCoords, haversineDistance } from './geo';
import { Star } from 'lucide-react';
import 'leaflet/dist/leaflet.css';
import type { Worker } from './geo';

interface WorkerMapProps {
  workers: Worker[];
  onSelect: (worker: Worker) => void;
  userLocation?: { lat: number; lng: number } | null;
  t: Record<string, string>;
}

const orangeIcon = new Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-orange.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41],
});

const userIcon = new Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-teal.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41],
});

function MapUpdater({ center, zoom }: { center: [number, number]; zoom: number }) {
  const map = useMap();
  map.setView(center, zoom, { animate: true });
  return null;
}

export default function WorkerMap({ workers, onSelect, userLocation, t }: WorkerMapProps) {
  const center: [number, number] = userLocation
    ? [userLocation.lat, userLocation.lng]
    : [-33.0, -64.0];

  return (
    <div className="h-56 rounded-2xl overflow-hidden shadow-lg border border-border">
      <MapContainer
        center={center}
        zoom={userLocation ? 9 : 5}
        style={{ height: '100%', width: '100%' }}
        zoomControl={true}
        scrollWheelZoom={false}
      >
        <MapUpdater center={center} zoom={userLocation ? 9 : 5} />
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        {userLocation && (
          <Marker position={[userLocation.lat, userLocation.lng]} icon={userIcon}>
            <Popup>
              <b>Tu ubicación</b>
            </Popup>
          </Marker>
        )}
        {workers.map((worker) => {
          const coords = getWorkerCoords(worker);
          const dist = userLocation
            ? haversineDistance(userLocation.lat, userLocation.lng, coords.lat, coords.lng)
            : null;

          return (
            <Marker
              key={worker.id}
              position={[coords.lat, coords.lng]}
              icon={orangeIcon}
              eventHandlers={{ click: () => onSelect(worker) }}
            >
              <Popup>
                <div className="text-sm min-w-[150px]">
                  <div className="flex items-center gap-2 mb-1">
                    <img
                      src={worker.avatar || `https://placehold.co/32x32/0d9488/ffffff?text=${worker.name?.charAt(0)}`}
                      alt=""
                      className="w-8 h-8 rounded-full object-cover"
                      onError={(e) => {
                        e.currentTarget.src = 'https://placehold.co/32x32/ccc/fff?text=W';
                      }}
                    />
                    <div>
                      <p className="font-bold">{worker.name}</p>
                      <p className="text-xs text-gray-500">{worker.service}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1 text-amber-500">
                    <Star className="w-3 h-3 fill-amber-400" />
                    <span className="text-xs font-bold">{(worker.rating || 5).toFixed(1)}</span>
                  </div>
                  {dist !== null && (
                    <p className="text-xs text-gray-500 mt-1">
                      📍 {dist} {t.nearby || 'km'}
                    </p>
                  )}
                  <button
                    onClick={() => onSelect(worker)}
                    className="mt-2 w-full text-xs bg-orange-500 text-white rounded-lg py-1 font-semibold hover:bg-orange-600 transition"
                  >
                    Ver perfil
                  </button>
                </div>
              </Popup>
            </Marker>
          );
        })}
      </MapContainer>
    </div>
  );
}
