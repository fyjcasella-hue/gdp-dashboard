export const WORLD_COUNTRIES = [
  'Argentina', 'Australia', 'Bangladesh', 'Belgium', 'Bolivia', 'Brazil', 'Canada', 'Chile',
  'China', 'Colombia', 'Czech Republic', 'Denmark', 'Ecuador', 'Egypt', 'France', 'Germany',
  'Ghana', 'Greece', 'India', 'Indonesia', 'Israel', 'Italy', 'Japan', 'Kenya', 'Malaysia',
  'Mexico', 'Morocco', 'Netherlands', 'New Zealand', 'Nigeria', 'Norway', 'Pakistan',
  'Paraguay', 'Peru', 'Philippines', 'Poland', 'Portugal', 'Romania', 'Russia', 'Saudi Arabia',
  'Singapore', 'South Africa', 'South Korea', 'Spain', 'Sweden', 'Switzerland', 'Thailand',
  'Turkey', 'UAE', 'United Kingdom', 'United States', 'Uruguay', 'Venezuela'
];

export const COUNTRY_COORDS: Record<string, { lat: number; lng: number }> = {
  'Argentina': { lat: -34.6, lng: -58.4 },
  'Brazil': { lat: -15.8, lng: -47.9 },
  'Mexico': { lat: 19.4, lng: -99.1 },
  'Colombia': { lat: 4.7, lng: -74.1 },
  'Chile': { lat: -33.5, lng: -70.6 },
  'Peru': { lat: -12.1, lng: -77.0 },
  'United States': { lat: 38.9, lng: -77.0 },
  'Spain': { lat: 40.4, lng: -3.7 },
  'France': { lat: 48.9, lng: 2.3 },
  'Germany': { lat: 52.5, lng: 13.4 },
  'Italy': { lat: 41.9, lng: 12.5 },
  'United Kingdom': { lat: 51.5, lng: -0.1 },
  'Australia': { lat: -35.3, lng: 149.1 },
  'China': { lat: 39.9, lng: 116.4 },
  'Japan': { lat: 35.7, lng: 139.7 },
  'India': { lat: 28.6, lng: 77.2 }
};

export const LOCALITY_COORDS: Record<string, { lat: number; lng: number }> = {
  'Córdoba Capital': { lat: -31.42, lng: -64.19 },
  'Rosario': { lat: -32.95, lng: -60.64 },
  'La Plata': { lat: -34.92, lng: -57.95 },
  'Mar del Plata': { lat: -38.00, lng: -57.56 },
  'Mendoza Capital': { lat: -32.89, lng: -68.84 },
  'Villa Carlos Paz': { lat: -31.42, lng: -64.50 },
  'Buenos Aires': { lat: -34.61, lng: -58.38 },
  'México DF': { lat: 19.43, lng: -99.13 },
  'São Paulo': { lat: -23.55, lng: -46.63 },
  'Lima': { lat: -12.05, lng: -77.04 },
  'Bogotá': { lat: 4.71, lng: -74.07 },
  'Madrid': { lat: 40.42, lng: -3.70 },
  'New York': { lat: 40.71, lng: -74.01 },
  'Los Angeles': { lat: 34.05, lng: -118.24 },
};

export const SERVICE_CATEGORIES: { label: string; services: string[] }[] = [
  {
    label: 'Automotor y transporte',
    services: ['Chapista y Pintura de Autos', 'Electricista de Autos', 'Grúa y Auxilio en Ruta', 'Lavadero de Autos a Domicilio', 'Mecánico', 'Remisero / Chofer Particular'],
  },
  {
    label: 'Construcción y obra',
    services: ['Albañil', 'Carpintero de Obra', 'Colocador de Pisos y Revestimientos', 'Demolición y Escombros', 'Encofrador', 'Revocador', 'Techista / Impermeabilizador', 'Yesero / Durlocero'],
  },
  {
    label: 'Eventos y oficios varios',
    services: ['Abogado a Domicilio', 'Animador de Fiestas Infantiles', 'Cocinero / Chef a Domicilio', 'Contador / Asesor Impositivo', 'Cuidador de Adultos Mayores', 'DJ', 'Fotógrafo / Camarógrafo', 'Maestro Particular / Tutor', 'Paseador de Perros / Pet Sitter', 'Peluquero Canino', 'Profe de Inglés / Idiomas', 'Repositor y Armado de Stands', 'Sereno / Cuidador', 'Otros'],
  },
  {
    label: 'Hogar y mantenimiento',
    services: ['Destapaciones', 'Enfermero a Domicilio', 'Fumigador / Control de Plagas', 'Gomero / Techador de Gomapluma', 'Limpieza de Tanques y Cisternas', 'Limpieza de Vidrios en Altura', 'Limpieza Profesional', 'Plomero Cloacal', 'Servicio de Mudanza y Fletes'],
  },
  {
    label: 'Instalaciones',
    services: ['Electricista Matriculado', 'Gasista Matriculado', 'Instalador de Aire Acondicionado', 'Instalador de Alarmas y CCTV', 'Instalador de Paneles Solares', 'Instalador de Portones Automáticos', 'Instalador de Redes y Cableado', 'Plomero / Sanitarista'],
  },
  {
    label: 'Jardín y exterior',
    services: ['Parquista / Jardinero', 'Piletas: Instalación y Mantenimiento', 'Podador de Árboles', 'Quincho y Asadores'],
  },
  {
    label: 'Tecnología',
    services: ['Diseñador Web / Freelance', 'Soporte de Redes y WiFi', 'Técnico de Celulares', 'Técnico de Electrodomésticos', 'Técnico de PC / Notebook', 'Técnico de TV y Audio'],
  },
  {
    label: 'Terminaciones',
    services: ['Carpintero / Mueblero', 'Cerrajero', 'Decorador de Interiores', 'Herrero / Soldador', 'Lustrador de Muebles', 'Pintor', 'Tapicero', 'Vidrio y Aluminio'],
  },
];

export const WORKER_SERVICES = [
  'Abogado a Domicilio',
  'Albañil',
  'Animador de Fiestas Infantiles',
  'Carpintero / Mueblero',
  'Carpintero de Obra',
  'Cerrajero',
  'Chapista y Pintura de Autos',
  'Cocinero / Chef a Domicilio',
  'Colocador de Pisos y Revestimientos',
  'Contador / Asesor Impositivo',
  'Cuidador de Adultos Mayores',
  'Decorador de Interiores',
  'Demolición y Escombros',
  'Destapaciones',
  'Diseñador Web / Freelance',
  'DJ',
  'Electricista de Autos',
  'Electricista Matriculado',
  'Encofrador',
  'Enfermero a Domicilio',
  'Fotógrafo / Camarógrafo',
  'Fumigador / Control de Plagas',
  'Gasista Matriculado',
  'Gomero / Techador de Gomapluma',
  'Grúa y Auxilio en Ruta',
  'Herrero / Soldador',
  'Instalador de Aire Acondicionado',
  'Instalador de Alarmas y CCTV',
  'Instalador de Paneles Solares',
  'Instalador de Portones Automáticos',
  'Instalador de Redes y Cableado',
  'Lavadero de Autos a Domicilio',
  'Limpieza de Tanques y Cisternas',
  'Limpieza de Vidrios en Altura',
  'Limpieza Profesional',
  'Lustrador de Muebles',
  'Maestro Particular / Tutor',
  'Mecánico',
  'Parquista / Jardinero',
  'Paseador de Perros / Pet Sitter',
  'Peluquero Canino',
  'Piletas: Instalación y Mantenimiento',
  'Pintor',
  'Plomero / Sanitarista',
  'Plomero Cloacal',
  'Podador de Árboles',
  'Profe de Inglés / Idiomas',
  'Quincho y Asadores',
  'Remisero / Chofer Particular',
  'Repositor y Armado de Stands',
  'Revocador',
  'Sereno / Cuidador',
  'Servicio de Mudanza y Fletes',
  'Soporte de Redes y WiFi',
  'Tapicero',
  'Techista / Impermeabilizador',
  'Técnico de Celulares',
  'Técnico de Electrodomésticos',
  'Técnico de PC / Notebook',
  'Técnico de TV y Audio',
  'Vidrio y Aluminio',
  'Yesero / Durlocero',
  'Otros',
];

export interface Worker {
  id: string;
  name: string;
  service: string;       // legacy field, kept for backward compat
  services?: string[];   // new: array of services
  avatar?: string;
  bio?: string;
  zone_country?: string;
  zone_province?: string;
  zone_locality?: string;
  lat?: number;
  lng?: number;
  price_range?: string;
  rating?: number;
  review_count?: number;
  available?: boolean;
  portfolio?: string[];
  user_email?: string;
}

/** Returns all services for a worker, falling back to the legacy single field */
export function getWorkerServices(worker: Worker): string[] {
  if (worker.services && worker.services.length > 0) return worker.services;
  if (worker.service) return [worker.service];
  return [];
}

export function getWorkerCoords(worker: Worker): { lat: number; lng: number } {
  if (worker.lat && worker.lng) {
    return { lat: Number(worker.lat), lng: Number(worker.lng) };
  }
  const loc = LOCALITY_COORDS[worker.zone_locality || ''];
  if (loc) {
    return { lat: loc.lat + (Math.random() - 0.5) * 0.1, lng: loc.lng + (Math.random() - 0.5) * 0.1 };
  }
  const country = COUNTRY_COORDS[worker.zone_country || ''];
  if (country) {
    return { lat: country.lat + (Math.random() - 0.5) * 2, lng: country.lng + (Math.random() - 0.5) * 2 };
  }
  return { lat: -34.6 + (Math.random() - 0.5) * 5, lng: -58.4 + (Math.random() - 0.5) * 5 };
}

export function haversineDistance(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1 * Math.PI / 180) *
    Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLng / 2) ** 2;
  return Math.round(R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)));
}
