import { Star, MapPin, Navigation } from 'lucide-react';
import type { Worker } from './geo';
import { getWorkerServices } from './geo';

interface WorkerCardProps {
  worker: Worker;
  onSelect: (worker: Worker) => void;
  distance?: number | null;
  t: Record<string, string>;
}

export default function WorkerCard({ worker, onSelect, distance, t }: WorkerCardProps) {
  return (
    <div
      onClick={() => onSelect(worker)}
      className="bg-card rounded-2xl border border-border flex flex-col items-center text-center cursor-pointer hover:shadow-lg hover:-translate-y-0.5 transition-all duration-200 relative overflow-hidden group card-shadow"
    >
      {/* Top accent bar */}
      <div className="w-full h-1 gradient-brand opacity-70 group-hover:opacity-100 transition-opacity" />

      <div className="p-4 flex flex-col items-center w-full">
        {/* Available badge */}
        {worker.available && (
          <div className="absolute top-3 left-3 flex items-center gap-1 bg-green-500 text-white text-[9px] font-bold px-1.5 py-0.5 rounded-full shadow-sm">
            <div className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
            Ahora
          </div>
        )}

        {/* Price badge */}
        <div className="absolute top-3 right-3 bg-secondary/10 text-secondary text-[10px] font-black px-1.5 py-0.5 rounded-lg">
          {worker.price_range || '$'}
        </div>

        {/* Avatar */}
        <div className="relative mb-3 mt-3">
          <div className="w-16 h-16 rounded-2xl border-2 border-secondary/40 overflow-hidden">
            <img
              src={worker.avatar || `https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=80&h=80&fit=crop&crop=face`}
              alt={worker.name}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              onError={(e) => {
                e.currentTarget.src = `https://placehold.co/80x80/0d9488/ffffff?text=${worker.name?.charAt(0)}`;
              }}
            />
          </div>
        </div>

        <h3 className="text-sm font-black text-foreground truncate w-full leading-tight">{worker.name}</h3>
        {/* Services chips — show up to 2, then "+N" */}
        <div className="flex flex-wrap gap-1 mt-1 justify-center">
          {getWorkerServices(worker).slice(0, 2).map((s) => (
            <span key={s} className="text-[9px] font-bold bg-secondary/10 text-secondary px-1.5 py-0.5 rounded-md leading-tight">
              {s}
            </span>
          ))}
          {getWorkerServices(worker).length > 2 && (
            <span className="text-[9px] font-bold bg-muted text-muted-foreground px-1.5 py-0.5 rounded-md leading-tight">
              +{getWorkerServices(worker).length - 2}
            </span>
          )}
        </div>

        {/* Rating */}
        <div className="flex items-center mt-2 gap-1 bg-amber-50 dark:bg-amber-950/30 px-2 py-1 rounded-lg">
          <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
          <span className="text-xs font-black text-foreground">{(worker.rating || 5.0).toFixed(1)}</span>
          <span className="text-xs text-muted-foreground">({worker.review_count || 0})</span>
        </div>

        {/* Location */}
        <div className="flex items-center gap-1 mt-2 w-full justify-center">
          <MapPin className="w-3 h-3 text-muted-foreground flex-shrink-0" />
          <p className="text-xs text-muted-foreground truncate">
            {worker.zone_locality || worker.zone_country || 'Sin zona'}
          </p>
        </div>

        {/* Distance */}
        {distance !== null && distance !== undefined && (
          <div className="flex items-center gap-1 mt-1.5 bg-primary/10 text-primary px-2.5 py-1 rounded-full">
            <Navigation className="w-3 h-3" />
            <span className="text-xs font-bold">{distance} {t.nearby || 'km'}</span>
          </div>
        )}
      </div>
    </div>
  );
}
