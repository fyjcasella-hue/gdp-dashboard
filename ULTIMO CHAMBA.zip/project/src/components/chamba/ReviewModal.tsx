import { useState } from 'react';
import { Star, X, Send } from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuth } from '@/lib/AuthContext';

interface ReviewModalProps {
  jobId: string;
  workerId: string;
  workerName: string;
  onClose: () => void;
  onDone: () => void;
}

export default function ReviewModal({ jobId, workerId, workerName, onClose, onDone }: ReviewModalProps) {
  const [rating, setRating] = useState(5);
  const [hovered, setHovered] = useState(0);
  const [comment, setComment] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const { user, profile } = useAuth();

  const handleSubmit = async () => {
    if (!rating || !user) return;
    setSubmitting(true);

    const { error } = await supabase.from('reviews').insert({
      worker_id: workerId,
      job_id: jobId,
      client_email: user.email,
      client_name: profile?.full_name || user.email,
      rating,
      comment: comment.trim() || null,
    });

    if (!error) {
      onDone();
      onClose();
    }
    setSubmitting(false);
  };

  const labels = ['', 'Muy malo', 'Malo', 'Regular', 'Bueno', 'Excelente'];

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/50 backdrop-blur-sm px-4 pb-8">
        <motion.div
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 100, opacity: 0 }}
          className="w-full max-w-lg bg-card rounded-3xl border border-border shadow-2xl p-6"
        >
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-black text-foreground">Calificar trabajo</h2>
            <button
              onClick={onClose}
              className="p-2 rounded-xl hover:bg-muted transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
          <p className="text-sm text-muted-foreground mb-4">
            ¿Cómo fue el trabajo de <strong className="text-foreground">{workerName}</strong>?
          </p>
          <div className="flex gap-2 justify-center mb-5">
            {[1, 2, 3, 4, 5].map((s) => (
              <button
                key={s}
                onMouseEnter={() => setHovered(s)}
                onMouseLeave={() => setHovered(0)}
                onClick={() => setRating(s)}
              >
                <Star
                  className={`w-10 h-10 transition-all ${
                    s <= (hovered || rating)
                      ? 'fill-amber-400 text-amber-400 scale-110'
                      : 'text-muted-foreground'
                  }`}
                />
              </button>
            ))}
          </div>
          <p className="text-center text-sm font-semibold text-amber-500 mb-4">
            {labels[rating]}
          </p>
          <textarea
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            placeholder="Contá tu experiencia... (opcional)"
            rows={3}
            className="w-full px-4 py-3 bg-muted border border-border rounded-2xl text-sm resize-none focus:outline-none focus:ring-2 focus:ring-primary mb-4"
          />
          <button
            onClick={handleSubmit}
            disabled={submitting}
            className="w-full bg-secondary text-secondary-foreground font-bold py-3.5 rounded-2xl flex items-center justify-center gap-2 hover:brightness-95 transition disabled:opacity-50"
          >
            {submitting ? (
              <div className="w-5 h-5 border-2 border-secondary-foreground/30 border-t-secondary-foreground rounded-full animate-spin" />
            ) : (
              <>
                <Send className="w-4 h-4" />
                Enviar reseña
              </>
            )}
          </button>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
