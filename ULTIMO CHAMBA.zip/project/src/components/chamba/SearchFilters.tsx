import { Search, X } from 'lucide-react';
import { WORLD_COUNTRIES, WORKER_SERVICES } from './geo';

interface Filters {
  search: string;
  service: string;
  country: string;
  city: string;
}

interface SearchFiltersProps {
  filters: Filters;
  onChange: (filters: Filters) => void;
  t: Record<string, string>;
}

export default function SearchFilters({ filters, onChange, t }: SearchFiltersProps) {
  const update = (key: keyof Filters, value: string) => {
    onChange({ ...filters, [key]: value });
  };

  return (
    <div className="space-y-2">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <input
          type="text"
          value={filters.search}
          onChange={(e) => update('search', e.target.value)}
          placeholder={t.searchPlaceholder || 'Buscar por nombre o profesión...'}
          className="w-full pl-10 pr-8 py-2.5 bg-muted border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary transition"
        />
        {filters.search && (
          <button
            onClick={() => update('search', '')}
            className="absolute right-3 top-1/2 -translate-y-1/2"
          >
            <X className="w-3.5 h-3.5 text-muted-foreground" />
          </button>
        )}
      </div>
      <div className="flex gap-2 overflow-x-auto pb-1">
        <select
          value={filters.service || 'Todos'}
          onChange={(e) => update('service', e.target.value)}
          className="flex-shrink-0 px-3 py-2 text-xs bg-card border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-primary min-w-[120px]"
        >
          <option value="Todos">{t.allServices || 'Todos los oficios'}</option>
          {WORKER_SERVICES.map((s) => (
            <option key={s} value={s}>{s}</option>
          ))}
        </select>
        <input
          type="text"
          value={filters.country || ''}
          onChange={(e) => update('country', e.target.value)}
          placeholder={t.allCountries || 'País'}
          list="countries-list"
          className="px-3 py-2 text-xs bg-card border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-primary w-32"
        />
        <datalist id="countries-list">
          {WORLD_COUNTRIES.map((c) => (
            <option key={c} value={c} />
          ))}
        </datalist>
        <input
          type="text"
          value={filters.city || ''}
          onChange={(e) => update('city', e.target.value)}
          placeholder={t.allCities || 'Ciudad'}
          className="flex-shrink-0 px-3 py-2 text-xs bg-card border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-primary w-28"
        />
      </div>
    </div>
  );
}
