import { useState, useEffect } from 'react';
import { Star } from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';
import { motion } from 'framer-motion';

interface Review {
  id: string;
  client_name: string | null;
  client_email: string;
  rating: number;
  comment: string | null;
}

interface ReviewListProps {
  workerId: string;
}

export default function ReviewList({ workerId }: ReviewListProps) {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase
      .from('reviews')
      .select('*')
      .eq('worker_id', workerId)
      .order('created_at', { ascending: false })
      .limit(10)
      .then(({ data, error }) => {
        if (!error && data) {
          setReviews(data);
        }
        setLoading(false);
      });
  }, [workerId]);

  if (loading) {
    return (
      <div className="space-y-2">
        {[1, 2].map((i) => (
          <div key={i} className="h-16 bg-muted rounded-2xl animate-pulse" />
        ))}
      </div>
    );
  }

  if (reviews.length === 0) {
    return <p className="text-sm text-muted-foreground text-center py-4">Aún no hay reseñas</p>;
  }

  return (
    <div className="space-y-3">
      {reviews.map((review, i) => (
        <motion.div
          key={review.id}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: i * 0.05 }}
          className="bg-muted rounded-2xl p-3"
        >
          <div className="flex items-center justify-between mb-1">
            <p className="text-sm font-semibold text-foreground">
              {review.client_name || review.client_email}
            </p>
            <div className="flex items-center gap-0.5">
              {[1, 2, 3, 4, 5].map((s) => (
                <Star
                  key={s}
                  className={`w-3 h-3 ${
                    s <= review.rating ? 'fill-amber-400 text-amber-400' : 'text-muted-foreground'
                  }`}
                />
              ))}
            </div>
          </div>
          {review.comment && (
            <p className="text-xs text-muted-foreground leading-relaxed">{review.comment}</p>
          )}
        </motion.div>
      ))}
    </div>
  );
}
