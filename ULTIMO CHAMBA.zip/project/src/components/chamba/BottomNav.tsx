import { useNavigate, useLocation } from 'react-router-dom';
import { Home, Briefcase, User, TrendingUp, Wrench } from 'lucide-react';
import { useAuth } from '@/lib/AuthContext';

interface BottomNavProps {
  t: Record<string, string>;
}

export default function BottomNav({ t }: BottomNavProps) {
  const navigate = useNavigate();
  const { pathname } = useLocation();
  const { profile } = useAuth();
  const isWorker = profile?.role === 'worker';

  const tabs = isWorker
    ? [
        { path: '/Home', icon: Home, label: t?.home || 'Inicio' },
        { path: '/WorkerDashboard', icon: TrendingUp, label: 'Dashboard' },
        { path: '/Settings', icon: Wrench, label: 'Trabajador', modeTab: true },
      ]
    : [
        { path: '/Home', icon: Home, label: t?.home || 'Inicio' },
        { path: '/Jobs', icon: Briefcase, label: t?.jobs || 'Trabajos' },
        { path: '/Settings', icon: User, label: 'Cliente', modeTab: true },
      ];

  return (
    <div className="fixed bottom-0 left-0 right-0 max-w-lg mx-auto z-30 px-3 pb-3 pt-1">
      <div className="bg-card/95 backdrop-blur-xl border border-border rounded-2xl shadow-xl flex overflow-hidden card-shadow-lg">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = pathname === tab.path;
          const isModeTab = (tab as { modeTab?: boolean }).modeTab;
          return (
            <button
              key={tab.path}
              onClick={() => navigate(tab.path)}
              className={`flex-1 flex flex-col items-center py-3 gap-0.5 transition-all duration-200 relative ${
                isActive ? 'text-secondary' : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              {isActive && (
                <span className="absolute inset-x-2 top-1 h-0.5 bg-secondary rounded-full" />
              )}
              <div className="relative mt-1">
                <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.5]' : 'stroke-[1.75]'}`} />
                {isModeTab && (
                  <span className={`absolute -top-1 -right-1.5 w-2 h-2 rounded-full border border-card ${
                    isWorker ? 'bg-primary' : 'bg-secondary'
                  }`} />
                )}
              </div>
              <span className={`text-xs font-semibold ${isActive ? 'font-bold' : ''}`}>{tab.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
