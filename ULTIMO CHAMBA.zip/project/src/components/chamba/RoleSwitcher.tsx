import { Search, Wrench } from 'lucide-react';

interface RoleSwitcherProps {
  role: 'client' | 'worker';
  onChange: (role: 'client' | 'worker') => void;
}

export default function RoleSwitcher({ role, onChange }: RoleSwitcherProps) {
  return (
    <div className="flex bg-muted rounded-full p-1 shadow-inner">
      <button
        onClick={() => onChange('client')}
        className={`flex-1 flex items-center justify-center gap-2 py-2 text-sm font-semibold rounded-full transition-all duration-200 ${
          role === 'client'
            ? 'bg-secondary text-secondary-foreground shadow-md'
            : 'text-muted-foreground hover:text-foreground'
        }`}
      >
        <Search className="w-4 h-4" />
        Buscar
      </button>
      <button
        onClick={() => onChange('worker')}
        className={`flex-1 flex items-center justify-center gap-2 py-2 text-sm font-semibold rounded-full transition-all duration-200 ${
          role === 'worker'
            ? 'bg-secondary text-secondary-foreground shadow-md'
            : 'text-muted-foreground hover:text-foreground'
        }`}
      >
        <Wrench className="w-4 h-4" />
        Ofrecer
      </button>
    </div>
  );
}
