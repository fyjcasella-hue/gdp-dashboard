import { Moon, Sun } from 'lucide-react';
import { useEffect, useState } from 'react';

export default function DarkModeToggle() {
  const [dark, setDark] = useState(() => localStorage.getItem('chamba_theme') === 'dark');

  useEffect(() => {
    if (dark) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('chamba_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('chamba_theme', 'light');
    }
  }, [dark]);

  useEffect(() => {
    if (localStorage.getItem('chamba_theme') === 'dark') {
      document.documentElement.classList.add('dark');
    }
  }, []);

  return (
    <button
      onClick={() => setDark((d) => !d)}
      className="p-2 rounded-xl bg-muted hover:bg-accent transition-colors"
      title={dark ? 'Modo claro' : 'Modo oscuro'}
    >
      {dark ? (
        <Sun className="w-4 h-4 text-amber-400" />
      ) : (
        <Moon className="w-4 h-4 text-muted-foreground" />
      )}
    </button>
  );
}
