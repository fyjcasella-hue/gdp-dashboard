import { useState } from 'react';
import { X, Send, CheckCircle, Info } from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';
import { sendEmail } from '@/lib/sendEmail';
import { useTranslation } from './i18n';

const CURRENCIES = ['ARS', 'USD', 'EUR', 'BRL', 'MXN', 'CLP', 'COP', 'PEN', 'GBP'];

interface QuoteModalProps {
  jobId: string;
  jobDescription: string | null;
  clientEmail: string;
  workerId: string;
  workerName: string;
  service?: string;
  onClose: () => void;
  onDone: () => void;
}

export default function QuoteModal({
  jobId,
  jobDescription,
  clientEmail,
  workerId,
  workerName,
  service,
  onClose,
  onDone,
}: QuoteModalProps) {
  const t = useTranslation();
  const [amount, setAmount] = useState('');
  const [currency, setCurrency] = useState('ARS');
  const [sena, setSena] = useState('');
  const [message, setMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);

  const totalAmount = parseFloat(amount) || 0;
  const senaAmount = parseFloat(sena) || 0;
  const senaValid = sena === '' || (senaAmount > 0 && senaAmount < totalAmount);

  const handleSubmit = async () => {
    if (!amount || totalAmount <= 0 || !senaValid) return;
    setSubmitting(true);

    const { error } = await supabase.from('quotes').insert({
      job_id: jobId,
      worker_id: workerId,
      worker_name: workerName,
      amount: totalAmount,
      currency,
      sena_amount: senaAmount > 0 ? senaAmount : null,
      message: message.trim() || null,
      status: 'pending',
    });

    if (!error) {
      setDone(true);
      sendEmail('quote_sent', clientEmail, {
        service: service || 'Servicio',
        worker_name: workerName,
        amount: totalAmount,
        currency,
        deposit_amount: senaAmount > 0 ? senaAmount : null,
        notes: message.trim() || null,
      });
      setTimeout(onDone, 1500);
    }
    setSubmitting(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/50 backdrop-blur-sm px-4 pb-4 sm:pb-0">
      <div className="bg-card w-full max-w-md rounded-3xl border border-border shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between px-5 pt-5 pb-3">
          <h3 className="font-black text-lg text-foreground">{t.sendQuote}</h3>
          <button onClick={onClose} className="p-2 rounded-xl hover:bg-muted transition-colors">
            <X className="w-5 h-5 text-muted-foreground" />
          </button>
        </div>

        {done ? (
          <div className="px-5 pb-8 flex flex-col items-center text-center gap-3">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
              <CheckCircle className="w-8 h-8 text-green-500" />
            </div>
            <p className="font-bold text-foreground">{t.quoteSent}</p>
            <p className="text-sm text-muted-foreground">El cliente recibirá tu presupuesto.</p>
          </div>
        ) : (
          <div className="px-5 pb-5 space-y-4">
            {/* Job context */}
            {jobDescription && (
              <div className="bg-muted rounded-xl p-3">
                <p className="text-xs text-muted-foreground uppercase font-semibold mb-1">Trabajo solicitado</p>
                <p className="text-sm text-foreground line-clamp-3">{jobDescription}</p>
                <p className="text-xs text-muted-foreground mt-1">{clientEmail}</p>
              </div>
            )}

            {/* Total amount */}
            <div>
              <label className="block text-sm font-bold text-foreground mb-2">
                {t.quoteAmount} *
              </label>
              <div className="flex gap-2">
                <select
                  value={currency}
                  onChange={(e) => setCurrency(e.target.value)}
                  className="w-24 px-3 py-2.5 bg-muted border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                >
                  {CURRENCIES.map((c) => (
                    <option key={c} value={c}>{c}</option>
                  ))}
                </select>
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="0.00"
                  min="0"
                  className="flex-1 px-4 py-2.5 bg-muted border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
            </div>

            {/* Seña / Adelanto */}
            <div>
              <label className="block text-sm font-bold text-foreground mb-1">
                Seña / Adelanto
                <span className="text-xs font-normal text-muted-foreground ml-2">(opcional)</span>
              </label>
              <p className="text-xs text-muted-foreground mb-2 flex items-start gap-1.5">
                <Info className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" />
                Si necesitás un adelanto para asegurar el trabajo, indicá el monto aquí.
              </p>
              <input
                type="number"
                value={sena}
                onChange={(e) => setSena(e.target.value)}
                placeholder={`0.00 ${currency}`}
                min="0"
                max={totalAmount > 0 ? totalAmount - 1 : undefined}
                className={`w-full px-4 py-2.5 bg-muted border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary transition ${
                  sena && !senaValid ? 'border-destructive' : 'border-border'
                }`}
              />
              {sena && !senaValid && (
                <p className="text-xs text-destructive mt-1">
                  La seña debe ser menor al monto total
                </p>
              )}
              {senaAmount > 0 && senaValid && totalAmount > 0 && (
                <div className="mt-2 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 rounded-xl p-2.5 text-xs text-amber-700 dark:text-amber-300">
                  Seña: {currency} {senaAmount.toLocaleString()} · Saldo al finalizar: {currency} {(totalAmount - senaAmount).toLocaleString()}
                </div>
              )}
            </div>

            {/* Message */}
            <div>
              <label className="block text-sm font-bold text-foreground mb-2">
                {t.quoteMessage}
              </label>
              <textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                rows={3}
                placeholder="Ej: Incluye materiales. Tiempo estimado: 2 horas."
                className="w-full px-3 py-2.5 bg-muted border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary resize-none"
              />
            </div>

            <button
              onClick={handleSubmit}
              disabled={submitting || !amount || totalAmount <= 0 || !senaValid}
              className="w-full bg-secondary text-secondary-foreground font-bold py-3.5 rounded-2xl shadow-md hover:brightness-95 transition disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {submitting ? (
                <div className="w-5 h-5 border-2 border-secondary-foreground/30 border-t-secondary-foreground rounded-full animate-spin" />
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  {t.sendQuote}
                </>
              )}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
