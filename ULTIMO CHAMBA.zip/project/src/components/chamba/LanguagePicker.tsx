import { useState } from 'react';
import { Globe } from 'lucide-react';
import { LANGUAGES } from './i18n';

interface LanguagePickerProps {
  onChange?: (code: string) => void;
}

export default function LanguagePicker({ onChange }: LanguagePickerProps) {
  const [open, setOpen] = useState(false);
  const current = localStorage.getItem('chamba_lang') || 'es';
  const currentLang = LANGUAGES.find((l) => l.code === current) || LANGUAGES[0];

  const select = (code: string) => {
    localStorage.setItem('chamba_lang', code);
    setOpen(false);
    onChange?.(code);
    window.location.reload();
  };

  return (
    <div className="relative">
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center gap-1.5 px-3 py-2 bg-muted rounded-xl text-sm font-medium hover:bg-accent transition-colors"
      >
        <span>{currentLang.flag}</span>
        <span className="hidden sm:inline">{currentLang.label}</span>
        <Globe className="w-3.5 h-3.5 text-muted-foreground" />
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setOpen(false)} />
          <div className="absolute right-0 top-full mt-1 z-50 bg-card border border-border rounded-2xl shadow-2xl overflow-hidden min-w-[160px]">
            {LANGUAGES.map((lang) => (
              <button
                key={lang.code}
                onClick={() => select(lang.code)}
                className={`w-full flex items-center gap-2.5 px-4 py-2.5 text-sm hover:bg-accent transition-colors text-left ${
                  lang.code === current
                    ? 'bg-accent/60 font-semibold text-primary'
                    : 'text-foreground'
                }`}
              >
                <span>{lang.flag}</span>
                <span>{lang.label}</span>
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
