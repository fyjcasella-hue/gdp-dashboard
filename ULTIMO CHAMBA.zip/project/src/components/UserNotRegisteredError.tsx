import { Shield, ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function UserNotRegisteredError() {
  const navigate = useNavigate();

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-b from-background to-muted p-6">
      <div className="max-w-md w-full p-8 bg-card rounded-3xl shadow-2xl border border-border text-center">
        <div className="w-20 h-20 rounded-2xl bg-destructive/10 flex items-center justify-center mx-auto mb-6">
          <Shield className="w-10 h-10 text-destructive" />
        </div>
        <h1 className="text-2xl font-bold text-foreground mb-3">Acceso Restringido</h1>
        <p className="text-muted-foreground mb-6 leading-relaxed">
          Tu cuenta aún no está habilitada para usar esta aplicación.
          Contactá al administrador para obtener acceso.
        </p>
        <div className="bg-muted rounded-2xl p-4 mb-6">
          <p className="text-xs text-muted-foreground">
            Si creés que esto es un error, verificá que estés usando la cuenta correcta.
          </p>
        </div>
        <button
          onClick={() => navigate('/')}
          className="w-full py-3 text-sm font-semibold text-primary bg-primary/10 rounded-xl hover:bg-primary/20 transition-colors flex items-center justify-center gap-2"
        >
          <ArrowLeft className="w-4 h-4" /> Volver al inicio
        </button>
      </div>
    </div>
  );
}
