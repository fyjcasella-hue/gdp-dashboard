const EDGE_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/send-email`;
const ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY;

type EmailType = 'job_request' | 'quote_sent' | 'job_finished' | 'job_completed';

export async function sendEmail(
  type: EmailType,
  to: string,
  data: Record<string, string | number | null | undefined>,
): Promise<void> {
  try {
    const res = await fetch(EDGE_URL, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${ANON_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ type, to, data }),
    });
    if (!res.ok) {
      const err = await res.text();
      console.error('[sendEmail] Error:', res.status, err);
    }
  } catch (err) {
    console.error('[sendEmail] Network error:', err);
  }
}
