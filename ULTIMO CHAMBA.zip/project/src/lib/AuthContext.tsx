import { createContext, useContext, useEffect, useState, useRef, ReactNode } from 'react';
import { supabase } from './supabaseClient';
import { User, Session } from '@supabase/supabase-js';

interface Profile {
  id: string;
  user_id: string;
  email: string;
  full_name: string | null;
  avatar: string | null;
  role: 'client' | 'worker';
}

interface AuthContextType {
  user: User | null;
  profile: Profile | null;
  session: Session | null;
  isLoading: boolean;
  needsRoleSelection: boolean;
  signIn: (email: string, password: string) => Promise<{ error: Error | null }>;
  signUp: (email: string, password: string, fullName?: string) => Promise<{ error: Error | null }>;
  signOut: () => Promise<void>;
  updateProfile: (updates: Partial<Profile>) => Promise<{ error: Error | null }>;
  completeRoleSelection: (role: 'client' | 'worker') => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [needsRoleSelection, setNeedsRoleSelection] = useState(false);

  // Once a new user triggers role selection, this ref prevents subsequent
  // onAuthStateChange fires (e.g. TOKEN_REFRESHED) from clearing the flag
  // before the user has made their choice.
  const roleSelectionPending = useRef(false);

  const fetchProfile = async (userId: string, userEmail: string) => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('user_id', userId)
        .maybeSingle();

      if (error) throw error;

      if (data) {
        setProfile(data);
        // Only clear role selection flag if it wasn't triggered by a fresh signup
        if (!roleSelectionPending.current) {
          setNeedsRoleSelection(false);
        }
      } else {
        // Brand new user — create placeholder and ask for role choice
        const { data: newProfile, error: insertError } = await supabase
          .from('profiles')
          .insert({ user_id: userId, email: userEmail, role: 'client' })
          .select()
          .single();
        if (!insertError && newProfile) {
          roleSelectionPending.current = true;
          setProfile(newProfile);
          setNeedsRoleSelection(true);
        }
      }
    } catch {
      // Silently fail
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    const timeout = setTimeout(() => setIsLoading(false), 5000);

    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (_event, session) => {
        setSession(session);
        setUser(session?.user ?? null);

        if (session?.user) {
          // setTimeout prevents deadlock inside auth state change handler
          setTimeout(() => {
            fetchProfile(session.user.id, session.user.email ?? '');
          }, 0);
        } else {
          setProfile(null);
          setNeedsRoleSelection(false);
          roleSelectionPending.current = false;
          setIsLoading(false);
        }
      }
    );

    return () => {
      clearTimeout(timeout);
      subscription.unsubscribe();
    };
  }, []);

  const signIn = async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    return { error };
  };

  const signUp = async (email: string, password: string, fullName?: string) => {
    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: { data: { full_name: fullName } },
    });
    return { error };
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    setUser(null);
    setProfile(null);
    setSession(null);
    setNeedsRoleSelection(false);
    roleSelectionPending.current = false;
  };

  const updateProfile = async (updates: Partial<Profile>) => {
    if (!profile) return { error: new Error('No profile found') };
    const { error } = await supabase
      .from('profiles')
      .update(updates)
      .eq('id', profile.id);
    if (!error) setProfile({ ...profile, ...updates });
    return { error };
  };

  // Called from RolePicker — persists role and clears the pending flag
  const completeRoleSelection = async (role: 'client' | 'worker') => {
    if (!profile) return;
    await supabase
      .from('profiles')
      .update({ role })
      .eq('id', profile.id);
    roleSelectionPending.current = false;
    setProfile({ ...profile, role });
    setNeedsRoleSelection(false);
  };

  return (
    <AuthContext.Provider value={{
      user,
      profile,
      session,
      isLoading,
      needsRoleSelection,
      signIn,
      signUp,
      signOut,
      updateProfile,
      completeRoleSelection,
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
