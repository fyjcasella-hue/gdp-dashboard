import { useLocation, useNavigate } from 'react-router-dom';
import { Home, ArrowLeft } from 'lucide-react';

export default function PageNotFound() {
  const location = useLocation();
  const navigate = useNavigate();
  const pageName = location.pathname.substring(1);

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-background">
      <div className="max-w-md w-full text-center space-y-6">
        <div className="relative">
          <h1 className="text-[120px] font-black text-muted/20 leading-none">404</h1>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center">
              <span className="text-3xl">🔍</span>
            </div>
          </div>
        </div>
        <div className="space-y-2">
          <h2 className="text-2xl font-bold text-foreground">Página no encontrada</h2>
          <p className="text-muted-foreground">
            La página <span className="font-semibold text-foreground">"{pageName}"</span> no existe o fue movida.
          </p>
        </div>
        <div className="flex gap-3 justify-center pt-4">
          <button
            onClick={() => navigate(-1)}
            className="px-5 py-2.5 text-sm font-semibold text-foreground bg-muted rounded-xl hover:bg-accent transition-colors flex items-center gap-2"
          >
            <ArrowLeft className="w-4 h-4" /> Volver
          </button>
          <button
            onClick={() => navigate('/Home')}
            className="px-5 py-2.5 text-sm font-semibold text-primary-foreground bg-primary rounded-xl hover:brightness-95 transition-all flex items-center gap-2 shadow-lg"
          >
            <Home className="w-4 h-4" /> Ir al inicio
          </button>
        </div>
      </div>
    </div>
  );
}
