import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabaseClient';
import { List, MapPin as MapIcon, Navigation, SlidersHorizontal } from 'lucide-react';
import WorkerCard from '@/components/chamba/WorkerCard';
import SearchFilters from '@/components/chamba/SearchFilters';
import LanguagePicker from '@/components/chamba/LanguagePicker';
import BottomNav from '@/components/chamba/BottomNav';
import WorkerMap from '@/components/chamba/WorkerMap';
import DarkModeToggle from '@/components/chamba/DarkModeToggle';
import { useTranslation } from '@/components/chamba/i18n';
import { haversineDistance, getWorkerCoords, type Worker } from '@/components/chamba/geo';
import { motion } from 'framer-motion';

const MOCK_WORKERS: Worker[] = [
  {
    id: 'w1',
    name: 'Ricardo Pérez',
    available: true,
    service: 'Herrería',
    zone_province: 'Córdoba',
    zone_locality: 'Córdoba Capital',
    zone_country: 'Argentina',
    rating: 4.8,
    review_count: 124,
    price_range: '$$',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=80&h=80&fit=crop',
    bio: 'Especialista en estructuras metálicas y portones automáticos.',
    portfolio: [],
  },
  {
    id: 'w2',
    name: 'Laura Gómez',
    service: 'Electricista',
    zone_province: 'Santa Fe',
    zone_locality: 'Rosario',
    zone_country: 'Argentina',
    rating: 5.0,
    review_count: 78,
    price_range: '$$$',
    avatar: 'https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?w=80&h=80&fit=crop',
    bio: 'Instalaciones eléctricas residenciales y comerciales, certificada.',
    portfolio: [],
  },
  {
    id: 'w3',
    name: 'Manuel Díaz',
    service: 'Albañilería',
    zone_province: 'Buenos Aires',
    zone_locality: 'La Plata',
    zone_country: 'Argentina',
    rating: 4.2,
    review_count: 201,
    price_range: '$',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=80&h=80&fit=crop',
    bio: 'Construcción y remodelación general.',
    portfolio: [],
  },
  {
    id: 'w4',
    name: 'Sofía Ramírez',
    service: 'Pintura',
    zone_province: 'Mendoza',
    zone_locality: 'Mendoza Capital',
    zone_country: 'Argentina',
    rating: 4.6,
    review_count: 55,
    price_range: '$$',
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=80&h=80&fit=crop',
    bio: 'Pintora profesional, interiores y exteriores.',
    portfolio: [],
  },
  {
    id: 'w5',
    name: 'Carlos Fontana',
    service: 'Plomería',
    zone_province: 'Buenos Aires',
    zone_locality: 'Mar del Plata',
    zone_country: 'Argentina',
    rating: 4.9,
    review_count: 310,
    price_range: '$$',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=80&h=80&fit=crop',
    bio: 'Plomero con 15 años de experiencia. Urgencias 24hs.',
    portfolio: [],
  },
  {
    id: 'w6',
    name: 'Ana Morales',
    service: 'Parquista / Jardinería',
    zone_province: 'Córdoba',
    zone_locality: 'Villa Carlos Paz',
    zone_country: 'Argentina',
    rating: 4.7,
    review_count: 42,
    price_range: '$',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=80&h=80&fit=crop',
    bio: 'Diseño y mantenimiento de jardines.',
    portfolio: [],
  },
];

interface Filters {
  search: string;
  service: string;
  country: string;
  city: string;
}

export default function Home() {
  const t = useTranslation();
  const navigate = useNavigate();
  const [workers, setWorkers] = useState<Worker[]>([]);
  const [viewMode, setViewMode] = useState<'list' | 'map'>('list');
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState<Filters>({
    search: '',
    service: 'Todos',
    country: '',
    city: '',
  });

  useEffect(() => {
    const fetchWorkers = async () => {
      const { data } = await supabase
        .from('workers')
        .select('*')
        .order('rating', { ascending: false })
        .limit(50);
      if (data && data.length > 0) {
        setWorkers([...MOCK_WORKERS, ...data]);
      } else {
        setWorkers(MOCK_WORKERS);
      }
    };
    fetchWorkers();
  }, []);

  const getLocation = () => {
    navigator.geolocation?.getCurrentPosition(
      (pos) => setUserLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
      () => {},
      { enableHighAccuracy: true }
    );
  };

  const filteredWorkers = workers.filter((w) => {
    const workerServices = w.services && w.services.length > 0 ? w.services : [w.service];
    const matchesService =
      filters.service === 'Todos' || !filters.service ||
      workerServices.includes(filters.service);
    const matchesCountry =
      !filters.country ||
      w.zone_country?.toLowerCase().includes(filters.country.toLowerCase()) ||
      w.zone_province?.toLowerCase().includes(filters.country.toLowerCase());
    const matchesCity =
      !filters.city || w.zone_locality?.toLowerCase().includes(filters.city.toLowerCase());
    const matchesSearch =
      !filters.search ||
      w.name.toLowerCase().includes(filters.search.toLowerCase()) ||
      workerServices.some((s) => s.toLowerCase().includes(filters.search.toLowerCase()));
    const isAvailable = w.available !== false;
    return matchesService && matchesCountry && matchesCity && matchesSearch && isAvailable;
  });

  const sortedWorkers = userLocation
    ? [...filteredWorkers].sort((a, b) => {
        const ca = getWorkerCoords(a);
        const cb = getWorkerCoords(b);
        return (
          haversineDistance(userLocation.lat, userLocation.lng, ca.lat, ca.lng) -
          haversineDistance(userLocation.lat, userLocation.lng, cb.lat, cb.lng)
        );
      })
    : filteredWorkers;

  const handleSelectWorker = (worker: Worker) => {
    navigate('/WorkerProfile', { state: { worker } });
  };

  const activeFilterCount = [
    filters.service !== 'Todos' && filters.service,
    filters.country,
    filters.city,
    filters.search,
  ].filter(Boolean).length;

  return (
    <div className="min-h-screen bg-background max-w-lg mx-auto relative">
      {/* Header */}
      <div className="sticky top-0 z-20 bg-card/95 backdrop-blur-xl border-b border-border shadow-sm">
        <div className="px-4 pt-4 pb-3">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <img src="/Gemini_Generated_Image_qvyypfqvyypfqvyy.png" alt="Chamba" className="h-10 w-auto object-contain" />
              <img src="/Gemini_Generated_Image_jhvq6ujhvq6ujhvq.png" alt="Chamba" className="h-8 w-auto object-contain" />
            </div>
            <div className="flex items-center gap-2">
              <DarkModeToggle />
              <LanguagePicker />
            </div>
          </div>

          {/* Search bar row */}
          <div className="flex items-center gap-2">
            <div className="flex-1 relative">
              <input
                type="text"
                value={filters.search}
                onChange={(e) => setFilters((f) => ({ ...f, search: e.target.value }))}
                placeholder={t.searchPlaceholder}
                className="w-full pl-4 pr-4 py-2.5 bg-muted border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary transition"
              />
            </div>
            <button
              onClick={() => setShowFilters((v) => !v)}
              className={`relative p-2.5 rounded-xl border-2 transition-all ${
                showFilters || activeFilterCount > 0
                  ? 'border-primary bg-primary/10 text-primary'
                  : 'border-border bg-muted text-muted-foreground hover:border-primary/50'
              }`}
            >
              <SlidersHorizontal className="w-4 h-4" />
              {activeFilterCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-secondary text-secondary-foreground text-[9px] font-black rounded-full flex items-center justify-center">
                  {activeFilterCount}
                </span>
              )}
            </button>
          </div>

          {/* Expandable filters */}
          {showFilters && (
            <div className="mt-2">
              <SearchFilters filters={filters} onChange={setFilters} t={t} />
            </div>
          )}
        </div>
      </div>

      {/* Controls row */}
      <div className="flex items-center justify-between px-4 mt-3 mb-2">
        <div className="flex bg-muted rounded-xl p-1 gap-0.5">
          <button
            onClick={() => setViewMode('list')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
              viewMode === 'list'
                ? 'bg-card shadow-sm text-foreground'
                : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            <List className="w-3.5 h-3.5" /> {t.list}
          </button>
          <button
            onClick={() => setViewMode('map')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
              viewMode === 'map'
                ? 'bg-card shadow-sm text-foreground'
                : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            <MapIcon className="w-3.5 h-3.5" /> {t.map}
          </button>
        </div>
        <button
          onClick={getLocation}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all border ${
            userLocation
              ? 'bg-primary text-primary-foreground border-primary glow-primary'
              : 'bg-card text-muted-foreground border-border hover:border-primary/50 hover:text-primary'
          }`}
        >
          <Navigation className="w-3.5 h-3.5" />
          {userLocation ? 'Ubicado' : 'Mi ubicación'}
        </button>
      </div>

      {/* Map */}
      {viewMode === 'map' && (
        <div className="px-4 mb-3">
          <WorkerMap
            workers={sortedWorkers}
            onSelect={handleSelectWorker}
            userLocation={userLocation}
            t={t}
          />
        </div>
      )}

      {/* Results */}
      <div className="px-4 pb-28">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-sm font-bold text-foreground">
            {t.results}{' '}
            <span className="text-muted-foreground font-normal">({sortedWorkers.length})</span>
          </h2>
        </div>

        {sortedWorkers.length > 0 ? (
          <div className="grid grid-cols-2 gap-3">
            {sortedWorkers.map((w, i) => {
              const coords = getWorkerCoords(w);
              const dist = userLocation
                ? haversineDistance(userLocation.lat, userLocation.lng, coords.lat, coords.lng)
                : null;
              return (
                <motion.div
                  key={w.id}
                  initial={{ opacity: 0, y: 16 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.035, duration: 0.3 }}
                >
                  <WorkerCard worker={w} onSelect={handleSelectWorker} distance={dist} t={t} />
                </motion.div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-20">
            <div className="w-16 h-16 bg-muted rounded-2xl flex items-center justify-center mx-auto mb-4">
              <SlidersHorizontal className="w-8 h-8 text-muted-foreground" />
            </div>
            <p className="text-foreground font-bold mb-1">{t.noResults}</p>
            <p className="text-sm text-muted-foreground">{t.noResultsHint}</p>
          </div>
        )}
      </div>

      <BottomNav t={t} />
    </div>
  );
}
