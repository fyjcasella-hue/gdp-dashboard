import { useNavigate, useLocation } from 'react-router-dom';
import { ArrowLeft, Star, MapPin, MessageCircle, Info, Images, Briefcase, Shield } from 'lucide-react';
import { useTranslation } from '@/components/chamba/i18n';
import { useAuth } from '@/lib/AuthContext';
import BottomNav from '@/components/chamba/BottomNav';
import ReviewList from '@/components/chamba/ReviewList';
import { motion } from 'framer-motion';
import type { Worker } from '@/components/chamba/geo';
import { getWorkerServices } from '@/components/chamba/geo';

export default function WorkerProfile() {
  const navigate = useNavigate();
  const { state } = useLocation();
  const t = useTranslation();
  const { profile } = useAuth();
  const isWorker = profile?.role === 'worker';
  const worker = state?.worker as Worker | undefined;

  if (!worker) {
    navigate('/Home');
    return null;
  }

  return (
    <motion.div
      initial={{ opacity: 0, x: 30 }}
      animate={{ opacity: 1, x: 0 }}
      className="min-h-screen bg-background max-w-lg mx-auto"
    >
      <div className="sticky top-0 z-10 bg-card/95 backdrop-blur border-b border-border px-4 py-3 flex items-center gap-3 shadow-sm">
        <button
          onClick={() => navigate(-1)}
          className="p-2 rounded-xl hover:bg-muted transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h2 className="font-bold text-foreground truncate">{worker.name}</h2>
      </div>

      <div className="pb-36">
        <div className="mx-4 mt-4 bg-card rounded-3xl border border-border shadow-lg overflow-hidden">
          <div className="h-20 bg-gradient-to-r from-primary to-primary/60" />
          <div className="px-5 pb-5 -mt-10">
            <img
              src={worker.avatar || `https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=96&h=96&fit=crop&crop=face`}
              alt={worker.name}
              className="w-20 h-20 rounded-2xl border-4 border-card shadow-xl object-cover mb-3"
              onError={(e) => {
                e.currentTarget.src = `https://placehold.co/96x96/ccc/fff?text=${worker.name?.charAt(0)}`;
              }}
            />
            <h1 className="text-2xl font-black text-foreground">{worker.name}</h1>
            <div className="flex flex-wrap gap-1.5 mt-1.5">
              {getWorkerServices(worker).map((s) => (
                <span key={s} className="text-xs font-bold bg-secondary/10 text-secondary px-2.5 py-1 rounded-full">
                  {s}
                </span>
              ))}
            </div>
            <div className="flex items-center gap-2 mt-3 flex-wrap">
              <div className="flex items-center gap-1.5 bg-amber-50 text-amber-600 px-3 py-1.5 rounded-full">
                <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                <span className="font-bold text-sm">{(worker.rating || 5.0).toFixed(1)}</span>
                <span className="text-xs text-amber-500">
                  ({worker.review_count || 0} {t.reviews})
                </span>
              </div>
              {worker.price_range && (
                <span className="bg-accent text-accent-foreground text-xs font-bold px-3 py-1.5 rounded-full">
                  {worker.price_range}
                </span>
              )}
            </div>
          </div>
        </div>

        <div className="mx-4 mt-3 bg-card rounded-2xl border border-border p-4 shadow-sm">
          <div className="flex items-center gap-2 mb-2">
            <Info className="w-4 h-4 text-primary" />
            <h3 className="font-bold text-foreground text-sm">{t.presentation}</h3>
          </div>
          <p className="text-muted-foreground text-sm leading-relaxed">
            {worker.bio || 'Este trabajador aún no ha escrito su presentación.'}
          </p>
        </div>

        <div className="mx-4 mt-3 bg-card rounded-2xl border border-border p-4 shadow-sm">
          <div className="flex items-center gap-2 mb-2">
            <MapPin className="w-4 h-4 text-secondary" />
            <h3 className="font-bold text-foreground text-sm">{t.coverageZone}</h3>
          </div>
          <div className="flex gap-6">
            {worker.zone_country && (
              <div>
                <p className="text-xs text-muted-foreground">{t.country}</p>
                <p className="font-semibold text-foreground text-sm">{worker.zone_country}</p>
              </div>
            )}
            {worker.zone_locality && (
              <div>
                <p className="text-xs text-muted-foreground">{t.city}</p>
                <p className="font-semibold text-foreground text-sm">{worker.zone_locality}</p>
              </div>
            )}
          </div>
        </div>

        {worker.portfolio && worker.portfolio.length > 0 && (
          <div className="mx-4 mt-3 bg-card rounded-2xl border border-border p-4 shadow-sm">
            <div className="flex items-center gap-2 mb-2">
              <Images className="w-4 h-4 text-primary" />
              <h3 className="font-bold text-foreground text-sm">{t.works}</h3>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {worker.portfolio.map((url, i) => (
                <img
                  key={i}
                  src={url}
                  alt={`Trabajo ${i + 1}`}
                  className="w-full aspect-square object-cover rounded-xl cursor-pointer hover:opacity-90 transition shadow-sm"
                  onClick={() => window.open(url, '_blank')}
                  onError={(e) => {
                    e.currentTarget.src = 'https://placehold.co/150x150/ef4444/ffffff?text=Error';
                  }}
                />
              ))}
            </div>
          </div>
        )}

        <div className="mx-4 mt-3 bg-card rounded-2xl border border-border p-4 shadow-sm">
          <div className="flex items-center gap-2 mb-3">
            <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
            <h3 className="font-bold text-foreground text-sm">Reseñas</h3>
          </div>
          <ReviewList workerId={worker.id} />
        </div>

        <div className="mx-4 mt-3 bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200 rounded-2xl p-4">
          <div className="flex items-center gap-2 mb-1">
            <Shield className="w-4 h-4 text-amber-600" />
            <p className="font-bold text-amber-700 text-sm">{t.paymentEscrow}</p>
          </div>
          <p className="text-xs text-amber-600">{t.paymentDesc}</p>
        </div>
      </div>

      <div className="fixed bottom-16 left-0 right-0 max-w-lg mx-auto p-4 bg-card border-t border-border shadow-2xl z-10">
        <div className="flex gap-2">
          <button
            onClick={() => navigate('/Chat', { state: { worker } })}
            className={`font-bold py-3 rounded-2xl text-sm hover:bg-accent transition flex items-center justify-center gap-2 border border-border ${
              isWorker ? 'flex-1 bg-muted text-foreground' : 'flex-1 bg-muted text-foreground'
            }`}
          >
            <MessageCircle className="w-4 h-4" />
            {t.contact}
          </button>
          {!isWorker && (
            <button
              onClick={() => navigate('/HireWorker', { state: { worker } })}
              className="flex-1 bg-secondary text-secondary-foreground font-bold py-3 rounded-2xl text-sm hover:brightness-95 transition flex items-center justify-center gap-2 shadow-lg"
            >
              <Briefcase className="w-4 h-4" />
              {t.hireNow}
            </button>
          )}
        </div>
      </div>
      <BottomNav t={t} />
    </motion.div>
  );
}
