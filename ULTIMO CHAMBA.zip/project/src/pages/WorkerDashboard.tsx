import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/lib/AuthContext';
import {
  TrendingUp, Star, Briefcase, DollarSign, CheckCircle, Clock, FileText, Zap,
  Flag, MessageCircle, AlertTriangle,
} from 'lucide-react';
import { useTranslation } from '@/components/chamba/i18n';
import { sendEmail } from '@/lib/sendEmail';
import BottomNav from '@/components/chamba/BottomNav';
import QuoteModal from '@/components/chamba/QuoteModal';
import { motion } from 'framer-motion';

interface WorkerProfile {
  id: string;
  name: string;
  service: string;
  avatar: string;
  available: boolean;
  alias?: string | null;
  cbu?: string | null;
  mp_link?: string | null;
}

interface Job {
  id: string;
  service: string;
  description: string | null;
  client_email: string;
  amount: number | null;
  currency: string | null;
  status: string;
  images?: string[] | null;
}

interface Review {
  id: string;
  client_name: string | null;
  client_email: string;
  rating: number;
  comment: string | null;
  created_at: string;
}

const STATUS_STYLE: Record<string, string> = {
  pending:     'text-amber-600 bg-amber-100 dark:bg-amber-950/40',
  accepted:    'text-blue-600 bg-blue-100 dark:bg-blue-950/40',
  in_progress: 'text-primary bg-accent',
  finished:    'text-purple-600 bg-purple-100 dark:bg-purple-950/40',
  completed:   'text-green-600 bg-green-100 dark:bg-green-950/40',
  cancelled:   'text-muted-foreground bg-muted',
  disputed:    'text-red-600 bg-red-100 dark:bg-red-950/40',
};

const STATUS_LABEL: Record<string, string> = {
  pending:     'Pendiente',
  accepted:    'Seña pendiente',
  in_progress: 'En progreso',
  finished:    'Esperando pago',
  completed:   'Completado',
  cancelled:   'Cancelado',
  disputed:    'En disputa',
};

export default function WorkerDashboard() {
  const t = useTranslation();
  const navigate = useNavigate();
  const { user, profile, isLoading } = useAuth();
  const [workerProfile, setWorkerProfile] = useState<WorkerProfile | null>(null);
  const [workerId, setWorkerId] = useState<string | null>(null);
  const [jobs, setJobs] = useState<Job[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);
  const [quoteJob, setQuoteJob] = useState<Job | null>(null);
  const [finishingJobId, setFinishingJobId] = useState<string | null>(null);
  const [confirmFinishJobId, setConfirmFinishJobId] = useState<string | null>(null);

  const fetchJobsAndReviews = useCallback(async (wId: string) => {
    const [jobsRes, reviewsRes] = await Promise.all([
      supabase.from('jobs').select('*').eq('worker_id', wId).order('created_at', { ascending: false }).limit(50),
      supabase.from('reviews').select('*').eq('worker_id', wId).order('created_at', { ascending: false }).limit(50),
    ]);
    if (jobsRes.data) setJobs(jobsRes.data);
    if (reviewsRes.data) setReviews(reviewsRes.data);
  }, []);

  // Initial load
  useEffect(() => {
    if (isLoading) return;
    if (!user || profile?.role !== 'worker') { navigate('/Home'); return; }

    const fetchData = async () => {
      const { data: workerData } = await supabase
        .from('workers').select('*').eq('user_email', user.email).maybeSingle();
      if (workerData) {
        setWorkerProfile(workerData);
        setWorkerId(workerData.id);
        await fetchJobsAndReviews(workerData.id);
      }
      setLoading(false);
    };
    fetchData();
  }, [user, profile, isLoading, navigate, fetchJobsAndReviews]);

  // Realtime subscription — only after we know workerId
  useEffect(() => {
    if (!workerId) return;
    const channel = supabase
      .channel(`worker-dashboard-${workerId}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'jobs', filter: `worker_id=eq.${workerId}` },
        () => fetchJobsAndReviews(workerId))
      .on('postgres_changes', { event: '*', schema: 'public', table: 'quotes' },
        () => fetchJobsAndReviews(workerId))
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [workerId, fetchJobsAndReviews]);

  const handleMarkFinished = async (job: Job) => {
    setFinishingJobId(job.id);
    setConfirmFinishJobId(null);
    await supabase.from('jobs').update({ status: 'finished' }).eq('id', job.id);
    setJobs((prev) => prev.map((j) => j.id === job.id ? { ...j, status: 'finished' } : j));
    setFinishingJobId(null);

    if (workerProfile) {
      const parts: string[] = [];
      if (workerProfile.alias) parts.push(`Alias: ${workerProfile.alias}`);
      if (workerProfile.cbu) parts.push(`CBU: ${workerProfile.cbu}`);
      if (workerProfile.mp_link) parts.push(`MercadoPago: ${workerProfile.mp_link}`);
      sendEmail('job_finished', job.client_email, {
        service: job.service,
        worker_name: workerProfile.name,
        amount: job.amount,
        currency: job.currency,
        payment_info: parts.join(' · ') || null,
      });
    }
  };

  if (isLoading || loading) {
    return (
      <div className="min-h-screen bg-background max-w-lg mx-auto flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  const completed = jobs.filter((j) => j.status === 'completed');
  const activeJobs = jobs.filter((j) => ['pending', 'accepted', 'in_progress', 'finished'].includes(j.status));
  const pendingNoQuote = jobs.filter((j) => j.status === 'pending' && j.amount === null);
  const senaAwaitedJobs = jobs.filter((j) => j.status === 'accepted');
  const inProgressJobs = jobs.filter((j) => j.status === 'in_progress');
  const finishedAwaitingPayment = jobs.filter((j) => j.status === 'finished');
  const totalEarned = completed.reduce((acc, j) => acc + (j.amount || 0), 0);
  const avgRating: string | number =
    reviews.length > 0
      ? Number((reviews.reduce((a, r) => a + r.rating, 0) / reviews.length).toFixed(1))
      : '—';

  const stats = [
    { label: 'Ganado', value: `$${totalEarned.toLocaleString()}`, icon: DollarSign, gradient: 'from-green-500 to-emerald-600' },
    { label: 'Completados', value: completed.length, icon: CheckCircle, gradient: 'from-primary to-teal-700' },
    { label: 'Activos', value: activeJobs.length, icon: Clock, gradient: 'from-amber-500 to-orange-500' },
    { label: 'Rating', value: avgRating, icon: Star, gradient: 'from-amber-400 to-yellow-500' },
  ];

  const urgentCount = pendingNoQuote.length + inProgressJobs.length + senaAwaitedJobs.length;

  return (
    <div className="min-h-screen bg-background max-w-lg mx-auto pb-28">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-card/95 backdrop-blur-xl border-b border-border shadow-sm">
        <div className="px-4 py-4 flex items-center justify-between">
          <h1 className="text-xl font-black text-foreground flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-secondary" />
            Dashboard
          </h1>
          {urgentCount > 0 && (
            <span className="bg-secondary text-secondary-foreground text-xs font-black px-2.5 py-1 rounded-full glow-secondary animate-pulse">
              {urgentCount} acción{urgentCount > 1 ? 'es' : ''}
            </span>
          )}
        </div>
      </div>

      <div className="p-4 space-y-4">
        {/* Worker profile card */}
        {workerProfile ? (
          <div className="gradient-brand rounded-3xl p-5 text-white card-shadow-lg glow-primary">
            <div className="flex items-center gap-4 mb-4">
              <div className="w-16 h-16 rounded-2xl border-2 border-white/30 overflow-hidden flex-shrink-0 bg-white/10">
                <img
                  src={workerProfile.avatar || `https://placehold.co/64x64/fff/0d9488?text=${workerProfile.name?.charAt(0)}`}
                  alt=""
                  className="w-full h-full object-cover"
                  onError={(e) => { e.currentTarget.src = 'https://placehold.co/64x64/ccc/fff?text=W'; }}
                />
              </div>
              <div>
                <p className="font-black text-xl leading-tight">{workerProfile.name}</p>
                <p className="text-white/75 text-sm font-medium">{workerProfile.service}</p>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <div className={`inline-flex items-center gap-2 text-xs font-bold px-3 py-1.5 rounded-full ${
                workerProfile.available ? 'bg-green-400/25 text-green-100' : 'bg-white/15 text-white/60'
              }`}>
                <div className={`w-2 h-2 rounded-full ${workerProfile.available ? 'bg-green-300 animate-pulse' : 'bg-white/40'}`} />
                {workerProfile.available ? 'Disponible ahora' : 'No disponible'}
              </div>
              <button
                onClick={() => navigate('/Settings')}
                className="text-xs text-white/70 hover:text-white transition font-semibold"
              >
                Editar perfil →
              </button>
            </div>
          </div>
        ) : (
          <div className="bg-card rounded-2xl border-2 border-dashed border-border p-6 text-center">
            <Zap className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
            <p className="text-sm text-muted-foreground mb-3">Completá tu perfil para aparecer en las búsquedas</p>
            <button
              onClick={() => navigate('/Settings')}
              className="bg-secondary text-secondary-foreground font-bold text-sm px-5 py-2.5 rounded-xl hover:brightness-95 transition"
            >
              Configurar perfil
            </button>
          </div>
        )}

        {/* Stats */}
        <div className="grid grid-cols-2 gap-3">
          {stats.map((stat, i) => {
            const Icon = stat.icon;
            return (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, scale: 0.92 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: i * 0.06, duration: 0.3 }}
                className="bg-card rounded-2xl border border-border p-4 card-shadow"
              >
                <div className={`w-10 h-10 bg-gradient-to-br ${stat.gradient} rounded-xl flex items-center justify-center mb-3 shadow-lg`}>
                  <Icon className="w-5 h-5 text-white" />
                </div>
                <p className="text-2xl font-black text-foreground">{stat.value}</p>
                <p className="text-xs text-muted-foreground mt-0.5 font-medium">{stat.label}</p>
              </motion.div>
            );
          })}
        </div>

        {/* Jobs awaiting quote */}
        {pendingNoQuote.length > 0 && (
          <div className="bg-card rounded-2xl border-2 border-secondary/40 overflow-hidden card-shadow">
            <div className="gradient-orange px-4 py-3 flex items-center gap-2">
              <FileText className="w-4 h-4 text-white" />
              <p className="text-white font-black text-sm">
                {pendingNoQuote.length} trabajo{pendingNoQuote.length > 1 ? 's' : ''} sin cotizar
              </p>
            </div>
            <div className="p-4 space-y-3">
              {pendingNoQuote.map((job) => (
                <div key={job.id} className="bg-muted rounded-2xl p-3">
                  <p className="text-sm font-black text-foreground">{job.service}</p>
                  {job.description && (
                    <p className="text-xs text-muted-foreground mt-1 line-clamp-3">{job.description}</p>
                  )}
                  {job.images && job.images.length > 0 && (
                    <div className="flex gap-1.5 mt-2 overflow-x-auto pb-1">
                      {job.images.map((url, i) => (
                        <a key={i} href={url} target="_blank" rel="noopener noreferrer" className="flex-shrink-0">
                          <img
                            src={url}
                            alt={`Foto ${i + 1}`}
                            className="w-16 h-16 rounded-xl object-cover border border-border hover:opacity-90 transition-opacity"
                          />
                        </a>
                      ))}
                    </div>
                  )}
                  <p className="text-xs text-muted-foreground mt-1 font-medium">{job.client_email}</p>
                  <button
                    onClick={() => setQuoteJob(job)}
                    className="mt-3 w-full gradient-orange text-white text-xs font-black py-2.5 rounded-xl hover:brightness-95 transition flex items-center justify-center gap-1.5 shadow-sm"
                  >
                    <FileText className="w-3.5 h-3.5" />
                    {t.sendQuote}
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Jobs waiting for client seña */}
        {senaAwaitedJobs.length > 0 && (
          <div className="bg-card rounded-2xl border-2 border-amber-300 dark:border-amber-800 overflow-hidden card-shadow">
            <div className="bg-gradient-to-r from-orange-500 to-amber-500 px-4 py-3 flex items-center gap-2">
              <Clock className="w-4 h-4 text-white" />
              <p className="text-white font-black text-sm">Esperando seña del cliente</p>
            </div>
            <div className="p-4 space-y-3">
              {senaAwaitedJobs.map((job) => (
                <div key={job.id} className="bg-muted rounded-2xl p-3">
                  <p className="text-sm font-black text-foreground">{job.service}</p>
                  {job.amount != null && (
                    <p className="text-sm font-black text-foreground mt-1">
                      {job.currency || 'ARS'} {job.amount.toLocaleString()}
                    </p>
                  )}
                  <p className="text-xs text-muted-foreground mt-1">{job.client_email}</p>
                  <p className="text-xs text-amber-600 dark:text-amber-400 font-semibold mt-2">
                    El cliente debe pagar la seña para que el trabajo inicie.
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* In-progress jobs: mark as finished */}
        {inProgressJobs.length > 0 && (
          <div className="bg-card rounded-2xl border-2 border-primary/30 overflow-hidden card-shadow">
            <div className="gradient-brand px-4 py-3 flex items-center gap-2">
              <Briefcase className="w-4 h-4 text-white" />
              <p className="text-white font-black text-sm">
                {inProgressJobs.length} trabajo{inProgressJobs.length > 1 ? 's' : ''} en progreso
              </p>
            </div>
            <div className="p-4 space-y-3">
              {inProgressJobs.map((job) => (
                <div key={job.id} className="bg-muted rounded-2xl p-3">
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <p className="text-sm font-black text-foreground">{job.service}</p>
                    {job.amount != null && (
                      <p className="text-sm font-black text-primary flex-shrink-0">
                        {job.currency || 'ARS'} {job.amount.toLocaleString()}
                      </p>
                    )}
                  </div>
                  {job.description && (
                    <p className="text-xs text-muted-foreground line-clamp-2 mb-1">{job.description}</p>
                  )}
                  <p className="text-xs text-muted-foreground font-medium mb-3">{job.client_email}</p>

                  {confirmFinishJobId === job.id ? (
                    /* Confirmation step */
                    <div className="bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 rounded-xl p-3 space-y-2.5">
                      <div className="flex items-center gap-2">
                        <AlertTriangle className="w-4 h-4 text-amber-600 flex-shrink-0" />
                        <p className="text-xs font-bold text-amber-700 dark:text-amber-300">
                          ¿Confirmás que el trabajo está terminado?
                        </p>
                      </div>
                      <p className="text-xs text-amber-600 dark:text-amber-400">
                        El cliente recibirá una notificación para realizar el pago.
                      </p>
                      <div className="flex gap-2">
                        <button
                          onClick={() => setConfirmFinishJobId(null)}
                          className="flex-1 border border-border text-muted-foreground text-xs font-bold py-2 rounded-xl hover:bg-card transition"
                        >
                          Cancelar
                        </button>
                        <button
                          onClick={() => handleMarkFinished(job)}
                          disabled={finishingJobId === job.id}
                          className="flex-1 gradient-brand text-white text-xs font-black py-2 rounded-xl hover:brightness-95 transition flex items-center justify-center gap-1 disabled:opacity-60"
                        >
                          {finishingJobId === job.id ? (
                            <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                          ) : (
                            <>
                              <Flag className="w-3 h-3" />
                              Confirmar
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                  ) : (
                    <button
                      onClick={() => setConfirmFinishJobId(job.id)}
                      className="w-full gradient-brand text-white text-xs font-black py-2.5 rounded-xl hover:brightness-95 transition flex items-center justify-center gap-1.5 shadow-sm"
                    >
                      <Flag className="w-3.5 h-3.5" />
                      Marcar como Finalizado
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Finished — awaiting client payment */}
        {finishedAwaitingPayment.length > 0 && (
          <div className="bg-card rounded-2xl border-2 border-purple-200 dark:border-purple-900 overflow-hidden card-shadow">
            <div className="bg-gradient-to-r from-purple-600 to-purple-500 px-4 py-3 flex items-center gap-2">
              <Clock className="w-4 h-4 text-white" />
              <p className="text-white font-black text-sm">Esperando pago del cliente</p>
            </div>
            <div className="p-4 space-y-3">
              {finishedAwaitingPayment.map((job) => (
                <div key={job.id} className="bg-muted rounded-2xl p-3">
                  <p className="text-sm font-black text-foreground">{job.service}</p>
                  {job.amount != null && (
                    <p className="text-base font-black text-green-600 mt-1">
                      {job.currency || 'ARS'} {job.amount.toLocaleString()}
                    </p>
                  )}
                  <p className="text-xs text-muted-foreground mt-1">{job.client_email}</p>
                  <p className="text-xs text-purple-600 dark:text-purple-400 font-semibold mt-2">
                    El cliente recibirá tus datos de cobro para realizar el pago.
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Recent jobs list */}
        <div className="bg-card rounded-2xl border border-border p-4 card-shadow">
          <h3 className="font-black text-foreground mb-4 flex items-center gap-2 text-sm">
            <div className="w-6 h-6 gradient-brand rounded-lg flex items-center justify-center">
              <Briefcase className="w-3.5 h-3.5 text-white" />
            </div>
            Historial de trabajos
          </h3>
          {jobs.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-6">
              Aún no tenés trabajos asignados
            </p>
          ) : (
            <div className="space-y-2">
              {jobs.slice(0, 8).map((job) => (
                <div key={job.id} className="flex items-center justify-between py-3 border-b border-border last:border-0">
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-bold text-foreground">{job.service}</p>
                    <p className="text-xs text-muted-foreground truncate mt-0.5">{job.client_email}</p>
                  </div>
                  <div className="text-right ml-3 flex flex-col items-end gap-1">
                    {job.amount ? (
                      <p className="text-sm font-black text-foreground">${job.amount.toLocaleString()}</p>
                    ) : (
                      <p className="text-xs text-secondary font-bold">Sin monto</p>
                    )}
                    <span className={`text-xs font-bold px-2 py-0.5 rounded-lg ${STATUS_STYLE[job.status] || STATUS_STYLE.pending}`}>
                      {STATUS_LABEL[job.status] || job.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Reviews */}
        <div className="bg-card rounded-2xl border border-border p-4 card-shadow">
          <h3 className="font-black text-foreground mb-4 flex items-center gap-2 text-sm">
            <div className="w-6 h-6 bg-gradient-to-br from-amber-400 to-yellow-500 rounded-lg flex items-center justify-center">
              <Star className="w-3.5 h-3.5 text-white" />
            </div>
            Opiniones de clientes
            <span className="ml-auto text-xs font-normal text-muted-foreground">{reviews.length} total</span>
          </h3>

          {reviews.length === 0 ? (
            <div className="text-center py-6">
              <MessageCircle className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
              <p className="text-sm text-muted-foreground">Aún no tenés opiniones</p>
              <p className="text-xs text-muted-foreground mt-1">Completá trabajos para recibir calificaciones</p>
            </div>
          ) : (
            <>
              <div className="flex items-center gap-4 bg-muted rounded-2xl p-4 mb-4">
                <div className="text-center flex-shrink-0">
                  <p className="text-4xl font-black text-foreground">{avgRating}</p>
                  <div className="flex gap-0.5 justify-center mt-1">
                    {[1, 2, 3, 4, 5].map((s) => (
                      <Star
                        key={s}
                        className={`w-3.5 h-3.5 ${s <= Number(avgRating) ? 'fill-amber-400 text-amber-400' : 'text-muted-foreground'}`}
                      />
                    ))}
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">{reviews.length} opinión{reviews.length !== 1 ? 'es' : ''}</p>
                </div>
                <div className="flex-1 space-y-1.5">
                  {[5, 4, 3, 2, 1].map((star) => {
                    const count = reviews.filter((r) => r.rating === star).length;
                    const pct = reviews.length > 0 ? (count / reviews.length) * 100 : 0;
                    return (
                      <div key={star} className="flex items-center gap-2">
                        <span className="text-xs text-muted-foreground w-2">{star}</span>
                        <div className="flex-1 h-1.5 bg-border rounded-full overflow-hidden">
                          <div className="h-full bg-amber-400 rounded-full transition-all" style={{ width: `${pct}%` }} />
                        </div>
                        <span className="text-xs text-muted-foreground w-4 text-right">{count}</span>
                      </div>
                    );
                  })}
                </div>
              </div>
              <div className="space-y-3">
                {reviews.map((review) => (
                  <div key={review.id} className="bg-muted rounded-2xl p-4">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <p className="text-sm font-bold text-foreground">
                          {review.client_name || review.client_email.split('@')[0]}
                        </p>
                        <p className="text-xs text-muted-foreground">{review.client_email}</p>
                      </div>
                      <div className="flex gap-0.5 flex-shrink-0">
                        {[1, 2, 3, 4, 5].map((s) => (
                          <Star
                            key={s}
                            className={`w-3.5 h-3.5 ${s <= review.rating ? 'fill-amber-400 text-amber-400' : 'text-muted-foreground'}`}
                          />
                        ))}
                      </div>
                    </div>
                    {review.comment && (
                      <p className="text-sm text-foreground leading-relaxed">{review.comment}</p>
                    )}
                    <p className="text-xs text-muted-foreground mt-2">
                      {new Date(review.created_at).toLocaleDateString('es-AR', { day: 'numeric', month: 'long', year: 'numeric' })}
                    </p>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
      </div>

      <BottomNav t={t} />

      {quoteJob && workerProfile && (
        <QuoteModal
          jobId={quoteJob.id}
          jobDescription={quoteJob.description}
          clientEmail={quoteJob.client_email}
          workerId={workerProfile.id}
          workerName={workerProfile.name}
          service={quoteJob.service}
          onClose={() => setQuoteJob(null)}
          onDone={() => {
            setQuoteJob(null);
            setJobs((prev) => prev.map((j) => j.id === quoteJob.id ? { ...j, amount: 0 } : j));
          }}
        />
      )}
    </div>
  );
}
