import { useState, useEffect, useRef } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { ArrowLeft, Send, Image as ImageIcon, X } from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/lib/AuthContext';
import type { Worker } from '@/components/chamba/geo';

interface ChatMessage {
  id: string;
  chat_id: string;
  sender_email: string;
  text: string | null;
  image_url: string | null;
  created_at: string;
}

export default function Chat() {
  const navigate = useNavigate();
  const { state } = useLocation();
  const worker = state?.worker as Worker | undefined;
  const { user } = useAuth();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isSending, setIsSending] = useState(false);

  useEffect(() => {
    if (!worker || !user) return;

    const chatId = `${worker.id}_${user.id}`;

    const fetchMessages = async () => {
      const { data } = await supabase
        .from('chat_messages')
        .select('*')
        .eq('chat_id', chatId)
        .order('created_at', { ascending: true })
        .limit(50);
      if (data) setMessages(data);
    };

    fetchMessages();

    const channel = supabase
      .channel(`chat:${chatId}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'chat_messages',
          filter: `chat_id=eq.${chatId}`,
        },
        (payload) => {
          setMessages((prev) => {
            if (prev.find((m) => m.id === payload.new.id)) return prev;
            return [...prev, payload.new as ChatMessage];
          });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [worker, user]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  if (!worker) {
    navigate('/Home');
    return null;
  }

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onloadend = () => setImagePreview(reader.result as string);
    reader.readAsDataURL(file);
  };

  const handleSend = async () => {
    if ((!inputText.trim() && !imagePreview) || isSending || !user) return;
    setIsSending(true);

    let imageUrl: string | null = null;
    if (imagePreview) {
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('chat-images')
        .upload(`${user.id}/${Date.now()}.jpg`, await fetch(imagePreview).then(r => r.blob()));

      if (!uploadError && uploadData) {
        const { data: urlData } = supabase.storage
          .from('chat-images')
          .getPublicUrl(uploadData.path);
        imageUrl = urlData.publicUrl;
      }
    }

    const chatId = `${worker.id}_${user.id}`;
    await supabase.from('chat_messages').insert({
      chat_id: chatId,
      sender_email: user.email,
      text: inputText.trim() || null,
      image_url: imageUrl,
    });

    setInputText('');
    setImagePreview(null);
    setIsSending(false);
  };

  const isMe = (msg: ChatMessage) => msg.sender_email === user?.email;
  const formatTime = (dateStr: string) =>
    dateStr ? new Date(dateStr).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '';

  return (
    <div className="flex flex-col h-screen max-w-lg mx-auto bg-background">
      <div className="flex items-center gap-3 px-4 py-3 bg-primary text-primary-foreground shadow-lg flex-shrink-0">
        <button
          onClick={() => navigate(-1)}
          className="p-2 rounded-xl hover:bg-white/10 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <img
          src={worker.avatar || `https://placehold.co/40x40/ccc/fff?text=${worker.name?.charAt(0)}`}
          alt={worker.name}
          className="w-9 h-9 rounded-full border-2 border-white/30 object-cover"
          onError={(e) => {
            e.currentTarget.src = 'https://placehold.co/40x40/ccc/fff?text=W';
          }}
        />
        <div className="flex-1 min-w-0">
          <p className="font-bold truncate text-sm">{worker.name}</p>
          <p className="text-xs opacity-70">{worker.service}</p>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {messages.length === 0 && (
          <div className="text-center py-12">
            <p className="text-4xl mb-2">💬</p>
            <p className="text-muted-foreground text-sm font-medium">Iniciá la conversación</p>
          </div>
        )}
        {messages.map((msg, i) => (
          <div key={msg.id || i} className={`flex ${isMe(msg) ? 'justify-end' : 'justify-start'}`}>
            <div
              className={`max-w-[78%] rounded-2xl px-4 py-2.5 shadow-sm ${
                isMe(msg)
                  ? 'bg-secondary text-secondary-foreground rounded-br-sm'
                  : 'bg-card text-foreground border border-border rounded-bl-sm'
              }`}
            >
              {msg.image_url && (
                <img
                  src={msg.image_url}
                  alt="img"
                  className="w-full max-h-48 object-cover rounded-xl mb-2 cursor-pointer"
                  onClick={() => window.open(msg.image_url!, '_blank')}
                />
              )}
              {msg.text && <p className="text-sm leading-relaxed">{msg.text}</p>}
              <p
                className={`text-xs mt-1 text-right ${
                  isMe(msg) ? 'text-secondary-foreground/70' : 'text-muted-foreground'
                }`}
              >
                {formatTime(msg.created_at)}
              </p>
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      <div className="px-3 py-3 bg-card border-t border-border shadow-inner flex-shrink-0">
        {imagePreview && (
          <div className="relative inline-block mb-2">
            <img src={imagePreview} alt="preview" className="h-14 w-14 object-cover rounded-xl border-2 border-secondary" />
            <button
              onClick={() => setImagePreview(null)}
              className="absolute -top-1.5 -right-1.5 bg-destructive text-destructive-foreground rounded-full w-5 h-5 flex items-center justify-center shadow"
            >
              <X className="w-3 h-3" />
            </button>
          </div>
        )}
        <div className="flex items-center gap-2">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && handleSend()}
            placeholder="Escribí tu mensaje..."
            className="flex-1 px-4 py-2.5 bg-muted border border-border rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-primary transition"
            disabled={isSending}
          />
          <input type="file" id="img-upload" accept="image/*" className="hidden" onChange={handleImageChange} />
          <button
            onClick={() => document.getElementById('img-upload')?.click()}
            className="p-2.5 rounded-full bg-muted hover:bg-accent transition-colors"
          >
            <ImageIcon className="w-5 h-5 text-muted-foreground" />
          </button>
          <button
            onClick={handleSend}
            disabled={(!inputText.trim() && !imagePreview) || isSending}
            className="p-2.5 rounded-full bg-secondary text-secondary-foreground hover:brightness-95 transition-all disabled:opacity-40 shadow"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
}
