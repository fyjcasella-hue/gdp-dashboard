import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/lib/AuthContext';
import {
  Briefcase, CheckCircle, Clock, AlertTriangle, XCircle, Star,
  FileText, ThumbsUp, ThumbsDown, Banknote, ChevronDown, ChevronUp,
  Flag, Copy, CreditCard, Coins, ExternalLink, ShieldAlert, History,
} from 'lucide-react';
import MercadoPagoLogo from '@/components/chamba/MercadoPagoLogo';
import { useTranslation } from '@/components/chamba/i18n';
import { sendEmail } from '@/lib/sendEmail';
import BottomNav from '@/components/chamba/BottomNav';
import ReviewModal from '@/components/chamba/ReviewModal';
import { motion, AnimatePresence } from 'framer-motion';

interface Job {
  id: string;
  client_email: string;
  client_name: string | null;
  worker_id: string;
  worker_name: string;
  service: string;
  description: string | null;
  amount: number | null;
  currency: string | null;
  payment_method: string;
  status: string;
  payment_status: string;
  sena_amount: number | null;
  sena_paid: boolean;
  created_at: string;
}

interface Quote {
  id: string;
  job_id: string;
  worker_id: string;
  worker_name: string;
  amount: number;
  currency: string;
  sena_amount: number | null;
  message: string | null;
  status: string;
  created_at: string;
}

interface WorkerPaymentInfo {
  alias: string | null;
  cbu: string | null;
  mp_link: string | null;
  name: string;
  user_email: string | null;
}

const STATUS_CONFIG: Record<string, { label: string; color: string; bg: string; icon: typeof Clock }> = {
  pending:     { label: 'Pendiente',      color: 'text-amber-700',        bg: 'bg-amber-100 dark:bg-amber-950/40',    icon: Clock },
  accepted:    { label: 'Seña pendiente', color: 'text-orange-700',       bg: 'bg-orange-100 dark:bg-orange-950/40',  icon: Coins },
  in_progress: { label: 'En progreso',    color: 'text-primary',          bg: 'bg-accent',                            icon: Briefcase },
  finished:    { label: 'Trabajo listo',  color: 'text-purple-700',       bg: 'bg-purple-100 dark:bg-purple-950/40',  icon: Flag },
  completed:   { label: 'Completado',     color: 'text-green-700',        bg: 'bg-green-100 dark:bg-green-950/40',    icon: CheckCircle },
  disputed:    { label: 'En disputa',     color: 'text-red-700',          bg: 'bg-red-100 dark:bg-red-950/40',        icon: AlertTriangle },
  cancelled:   { label: 'Cancelado',      color: 'text-muted-foreground', bg: 'bg-muted',                             icon: XCircle },
};

export default function Jobs() {
  const t = useTranslation();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [jobs, setJobs] = useState<Job[]>([]);
  const [quotes, setQuotes] = useState<Quote[]>([]);
  const [workerPaymentInfos, setWorkerPaymentInfos] = useState<Record<string, WorkerPaymentInfo>>({});
  const [loading, setLoading] = useState(true);
  const [reviewJob, setReviewJob] = useState<Job | null>(null);
  const [expandedJob, setExpandedJob] = useState<string | null>(null);
  const [payingJobId, setPayingJobId] = useState<string | null>(null);
  const [copiedText, setCopiedText] = useState('');
  const [activeTab, setActiveTab] = useState<'active' | 'history'>('active');
  const [confirmDisputeJobId, setConfirmDisputeJobId] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    if (!user) return;
    const { data: jobsData, error } = await supabase
      .from('jobs')
      .select('*')
      .eq('client_email', user.email)
      .order('created_at', { ascending: false })
      .limit(30);

    if (!error && jobsData) {
      setJobs(jobsData);
      if (jobsData.length > 0) {
        const jobIds = jobsData.map((j) => j.id);
        const { data: quotesData } = await supabase
          .from('quotes')
          .select('*')
          .in('job_id', jobIds)
          .order('created_at', { ascending: false });
        if (quotesData) setQuotes(quotesData);

        // Fetch worker payment info for jobs that require payment
        const paymentJobs = jobsData.filter((j) => ['accepted', 'in_progress', 'finished'].includes(j.status));
        const workerIds = [...new Set(paymentJobs.map((j) => j.worker_id).filter(Boolean))];
        if (workerIds.length > 0) {
          const { data: workersData } = await supabase
            .from('workers').select('id, name, alias, cbu, mp_link, user_email').in('id', workerIds);
          if (workersData) {
            const map: Record<string, WorkerPaymentInfo> = {};
            workersData.forEach((w) => { map[w.id] = { alias: w.alias, cbu: w.cbu, mp_link: w.mp_link, name: w.name, user_email: w.user_email }; });
            setWorkerPaymentInfos(map);
          }
        }
      }
    }
    setLoading(false);
  }, [user]);

  useEffect(() => {
    if (!user) { navigate('/Home'); return; }
    fetchData();
    const channel = supabase
      .channel('jobs-and-quotes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'jobs', filter: `client_email=eq.${user.email}` }, fetchData)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'quotes' }, fetchData)
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [user, navigate, fetchData]);

  const handleAcceptQuote = async (quote: Quote) => {
    const hasSena = quote.sena_amount != null && quote.sena_amount > 0;
    await supabase.from('quotes').update({ status: 'accepted' }).eq('id', quote.id);
    await supabase.from('jobs').update({
      amount: quote.amount,
      currency: quote.currency,
      sena_amount: quote.sena_amount || null,
      sena_paid: false,
      // With seña → stays 'accepted' until seña is confirmed; without → goes straight to in_progress
      status: hasSena ? 'accepted' : 'in_progress',
    }).eq('id', quote.job_id);
    setQuotes((prev) => prev.map((q) => q.id === quote.id ? { ...q, status: 'accepted' } : q));
    setJobs((prev) => prev.map((j) =>
      j.id === quote.job_id ? {
        ...j,
        amount: quote.amount,
        currency: quote.currency,
        sena_amount: quote.sena_amount || null,
        sena_paid: false,
        status: hasSena ? 'accepted' : 'in_progress',
      } : j
    ));
    setExpandedJob(null);
  };

  const handleRejectQuote = async (quote: Quote) => {
    await supabase.from('quotes').update({ status: 'rejected' }).eq('id', quote.id);
    setQuotes((prev) => prev.map((q) => q.id === quote.id ? { ...q, status: 'rejected' } : q));
  };

  const handleConfirmSena = async (job: Job) => {
    await supabase.from('jobs').update({ sena_paid: true, status: 'in_progress' }).eq('id', job.id);
    setJobs((prev) => prev.map((j) =>
      j.id === job.id ? { ...j, sena_paid: true, status: 'in_progress' } : j
    ));
    setPayingJobId(null);
  };

  const handleConfirmFinalPayment = async (job: Job) => {
    await supabase.from('jobs').update({ status: 'completed', payment_status: 'released' }).eq('id', job.id);
    setJobs((prev) => prev.map((j) =>
      j.id === job.id ? { ...j, status: 'completed', payment_status: 'released' } : j
    ));
    setPayingJobId(null);
    const workerInfo = workerPaymentInfos[job.worker_id];
    if (workerInfo?.user_email) {
      sendEmail('job_completed', workerInfo.user_email, {
        service: job.service,
        client_name: job.client_name || job.client_email,
        client_email: job.client_email,
        amount: job.amount,
        currency: job.currency,
      });
    }
  };

  const handleCancel = async (job: Job) => {
    await supabase.from('jobs').update({ status: 'cancelled' }).eq('id', job.id);
    setJobs((prev) => prev.map((j) => j.id === job.id ? { ...j, status: 'cancelled' } : j));
  };

  const handleDispute = async (job: Job) => {
    setConfirmDisputeJobId(null);
    await supabase.from('jobs').update({ status: 'disputed' }).eq('id', job.id);
    setJobs((prev) => prev.map((j) => j.id === job.id ? { ...j, status: 'disputed' } : j));
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text).then(() => {
      setCopiedText(label);
      setTimeout(() => setCopiedText(''), 2000);
    });
  };

  const getJobQuotes = (jobId: string) => quotes.filter((q) => q.job_id === jobId && q.status === 'pending');
  const getJobHasRejectedQuotes = (jobId: string) => quotes.some((q) => q.job_id === jobId && q.status === 'rejected');
  const getPendingQuoteCount = () => quotes.filter((q) => q.status === 'pending').length;

  const ACTIVE_STATUSES = ['pending', 'accepted', 'in_progress', 'finished', 'disputed'];
  const HISTORY_STATUSES = ['completed', 'cancelled'];
  const displayedJobs = jobs.filter((j) =>
    activeTab === 'active' ? ACTIVE_STATUSES.includes(j.status) : HISTORY_STATUSES.includes(j.status)
  );
  const historyCount = jobs.filter((j) => HISTORY_STATUSES.includes(j.status)).length;

  return (
    <div className="min-h-screen bg-background max-w-lg mx-auto pb-28">
      <div className="sticky top-0 z-10 bg-card/95 backdrop-blur-xl border-b border-border shadow-sm">
        <div className="px-4 pt-4 pb-0 flex items-center justify-between">
          <h1 className="text-xl font-black text-foreground">{t.myJobs}</h1>
          {getPendingQuoteCount() > 0 && (
            <span className="bg-secondary text-secondary-foreground text-xs font-black px-2.5 py-1 rounded-full glow-secondary">
              {getPendingQuoteCount()} presupuesto{getPendingQuoteCount() > 1 ? 's' : ''}
            </span>
          )}
        </div>
        {/* Tabs */}
        <div className="flex px-4 pt-3 pb-0 gap-0 border-b-0">
          <button
            onClick={() => setActiveTab('active')}
            className={`flex items-center gap-1.5 px-4 py-2.5 text-sm font-bold border-b-2 transition-colors ${
              activeTab === 'active'
                ? 'border-primary text-primary'
                : 'border-transparent text-muted-foreground hover:text-foreground'
            }`}
          >
            <Briefcase className="w-3.5 h-3.5" />
            Activos
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`flex items-center gap-1.5 px-4 py-2.5 text-sm font-bold border-b-2 transition-colors ${
              activeTab === 'history'
                ? 'border-primary text-primary'
                : 'border-transparent text-muted-foreground hover:text-foreground'
            }`}
          >
            <History className="w-3.5 h-3.5" />
            Historial
            {historyCount > 0 && (
              <span className="text-xs bg-muted text-muted-foreground px-1.5 py-0.5 rounded-full font-semibold">{historyCount}</span>
            )}
          </button>
        </div>
      </div>

      <div className="p-4 space-y-3">
        {loading ? (
          Array(3).fill(0).map((_, i) => (
            <div key={i} className="bg-card rounded-2xl p-5 border border-border animate-pulse h-32" />
          ))
        ) : displayedJobs.length === 0 ? (
          <div className="text-center py-20">
            <div className="w-20 h-20 gradient-brand rounded-3xl flex items-center justify-center mx-auto mb-5 glow-primary">
              {activeTab === 'history' ? <History className="w-10 h-10 text-white" /> : <Briefcase className="w-10 h-10 text-white" />}
            </div>
            <p className="text-foreground font-bold text-lg mb-1">
              {activeTab === 'history' ? 'Sin historial aún' : 'Sin trabajos activos'}
            </p>
            <p className="text-muted-foreground text-sm mb-6">
              {activeTab === 'history'
                ? 'Los trabajos completados y cancelados aparecerán aquí'
                : 'Encontrá un profesional y solicitá tu primer presupuesto'}
            </p>
            {activeTab === 'active' && (
              <button
                onClick={() => navigate('/Home')}
                className="bg-secondary text-secondary-foreground font-bold px-6 py-3 rounded-2xl shadow-lg glow-secondary hover:brightness-95 transition"
              >
                Buscar trabajadores
              </button>
            )}
          </div>
        ) : (
          displayedJobs.map((job, idx) => {
            const isFinished = job.status === 'finished';
            const isAccepted = job.status === 'accepted'; // waiting for seña
            const hasSena = job.sena_amount != null && job.sena_amount > 0;
            const remaining = (job.amount || 0) - (hasSena && job.sena_paid ? (job.sena_amount || 0) : 0);
            const statusCfg = STATUS_CONFIG[job.status] || STATUS_CONFIG.pending;
            const StatusIcon = statusCfg.icon;
            const pendingQuotes = getJobQuotes(job.id);
            const hasRejectedQuotes = getJobHasRejectedQuotes(job.id);
            const isExpanded = expandedJob === job.id;
            const payInfo = workerPaymentInfos[job.worker_id];
            const isPaying = payingJobId === job.id;

            return (
              <motion.div
                key={job.id}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.04 }}
                className="bg-card rounded-2xl border border-border card-shadow overflow-hidden"
              >
                {/* Status banners */}
                {isFinished && (
                  <div className="bg-gradient-to-r from-purple-600 to-purple-500 px-4 py-2 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Flag className="w-4 h-4 text-white" />
                      <p className="text-white text-xs font-bold">El trabajador finalizó el trabajo</p>
                    </div>
                    <span className="text-white/80 text-xs font-semibold">Pagá ahora</span>
                  </div>
                )}
                {isAccepted && hasSena && (
                  <div className="bg-gradient-to-r from-orange-500 to-amber-500 px-4 py-2 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Coins className="w-4 h-4 text-white" />
                      <p className="text-white text-xs font-bold">Pagá la seña para confirmar el trabajo</p>
                    </div>
                    <span className="text-white/80 text-xs font-semibold">
                      {job.currency} {job.sena_amount?.toLocaleString()}
                    </span>
                  </div>
                )}
                {!isFinished && !isAccepted && pendingQuotes.length > 0 && (
                  <div className="gradient-orange px-4 py-2 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <FileText className="w-4 h-4 text-white" />
                      <p className="text-white text-xs font-bold">
                        {pendingQuotes.length} presupuesto{pendingQuotes.length > 1 ? 's' : ''} recibido{pendingQuotes.length > 1 ? 's' : ''}
                      </p>
                    </div>
                    <span className="text-white/80 text-xs">Tap para ver</span>
                  </div>
                )}

                <div className="p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1 min-w-0 pr-3">
                      <p className="font-black text-foreground truncate text-base">{job.worker_name}</p>
                      <p className="text-sm text-secondary font-semibold">{job.service}</p>
                    </div>
                    <span className={`flex items-center gap-1 text-xs font-bold px-2.5 py-1 rounded-xl flex-shrink-0 ${statusCfg.bg} ${statusCfg.color}`}>
                      <StatusIcon className="w-3 h-3" />
                      {statusCfg.label}
                    </span>
                  </div>

                  {job.description && (
                    <p className="text-sm text-muted-foreground mb-3 line-clamp-2 bg-muted rounded-xl px-3 py-2">
                      {job.description}
                    </p>
                  )}

                  {/* Amount summary */}
                  {job.amount ? (
                    <div className="bg-muted rounded-xl px-3 py-2.5 mb-3 space-y-1.5">
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-muted-foreground">Total acordado</span>
                        <span className="text-sm font-black text-foreground">
                          {job.currency || 'ARS'} {job.amount.toLocaleString()}
                        </span>
                      </div>
                      {hasSena && (
                        <div className="flex items-center justify-between">
                          <span className="text-xs text-muted-foreground">
                            Seña {job.sena_paid ? '(pagada)' : '(pendiente)'}
                          </span>
                          <span className={`text-xs font-bold ${job.sena_paid ? 'text-green-600' : 'text-amber-600'}`}>
                            {job.currency} {job.sena_amount?.toLocaleString()}
                          </span>
                        </div>
                      )}
                      {hasSena && job.sena_paid && job.status !== 'completed' && (
                        <div className="flex items-center justify-between border-t border-border pt-1.5">
                          <span className="text-xs font-bold text-foreground">Saldo al finalizar</span>
                          <span className="text-sm font-black text-primary">
                            {job.currency} {remaining.toLocaleString()}
                          </span>
                        </div>
                      )}
                      <div className="flex items-center gap-1.5 pt-0.5">
                        {job.payment_method === 'cash' ? (
                          <Banknote className="w-3 h-3 text-amber-600" />
                        ) : (
                          <CreditCard className="w-3 h-3 text-primary" />
                        )}
                        <span className="text-xs text-muted-foreground">
                          {job.payment_method === 'cash' ? 'Efectivo' : 'Transferencia bancaria'}
                        </span>
                      </div>
                    </div>
                  ) : (
                    <div className={`flex items-center gap-2 px-3 py-2 rounded-xl border mb-3 ${
                      hasRejectedQuotes && !pendingQuotes.length
                        ? 'bg-red-50 dark:bg-red-950/20 border-red-200 dark:border-red-900'
                        : 'bg-secondary/8 border-secondary/20'
                    }`}>
                      {hasRejectedQuotes && !pendingQuotes.length
                        ? <XCircle className="w-4 h-4 text-red-500 flex-shrink-0" />
                        : <FileText className="w-4 h-4 text-secondary flex-shrink-0" />
                      }
                      <span className={`text-xs font-semibold ${
                        hasRejectedQuotes && !pendingQuotes.length ? 'text-red-600 dark:text-red-400' : 'text-secondary'
                      }`}>
                        {pendingQuotes.length > 0
                          ? 'Presupuesto recibido — revisá abajo'
                          : hasRejectedQuotes
                            ? 'El trabajador rechazó el presupuesto'
                            : 'Esperando presupuesto...'
                        }
                      </span>
                    </div>
                  )}

                  {/* === SEÑA PAYMENT BLOCK === */}
                  {isAccepted && hasSena && (
                    <div className="mb-3">
                      {!isPaying ? (
                        <button
                          onClick={() => setPayingJobId(job.id)}
                          className="w-full bg-gradient-to-r from-orange-500 to-amber-500 text-white font-black py-3 rounded-2xl shadow-lg hover:brightness-95 transition flex items-center justify-center gap-2"
                        >
                          <Coins className="w-4 h-4" />
                          Pagar seña — {job.currency} {job.sena_amount?.toLocaleString()}
                        </button>
                      ) : (
                        <PaymentPanel
                          label="Pago de seña"
                          amount={job.sena_amount!}
                          currency={job.currency || 'ARS'}
                          payInfo={payInfo}
                          payMethod={job.payment_method}
                          copiedText={copiedText}
                          onCopy={copyToClipboard}
                          onBack={() => setPayingJobId(null)}
                          onConfirm={() => handleConfirmSena(job)}
                          confirmLabel="Ya pagué la seña"
                        />
                      )}
                    </div>
                  )}

                  {/* === FINAL PAYMENT BLOCK === */}
                  {isFinished && (
                    <div className="mb-3">
                      {!isPaying ? (
                        <button
                          onClick={() => setPayingJobId(job.id)}
                          className="w-full bg-gradient-to-r from-purple-600 to-purple-500 text-white font-black py-3 rounded-2xl shadow-lg hover:brightness-95 transition flex items-center justify-center gap-2"
                        >
                          <CreditCard className="w-4 h-4" />
                          Pagar saldo — {job.currency} {remaining.toLocaleString()}
                        </button>
                      ) : (
                        <PaymentPanel
                          label={hasSena ? `Pago final (saldo)` : 'Pago final'}
                          amount={remaining}
                          currency={job.currency || 'ARS'}
                          payInfo={payInfo}
                          payMethod={job.payment_method}
                          copiedText={copiedText}
                          onCopy={copyToClipboard}
                          onBack={() => setPayingJobId(null)}
                          onConfirm={() => handleConfirmFinalPayment(job)}
                          confirmLabel="Ya pagué el total"
                        />
                      )}
                    </div>
                  )}

                  {/* Dispute confirmation */}
                  {confirmDisputeJobId === job.id && (
                    <div className="bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-900 rounded-2xl p-3.5 mb-3 space-y-2.5">
                      <div className="flex items-center gap-2">
                        <ShieldAlert className="w-4 h-4 text-red-600 flex-shrink-0" />
                        <p className="text-xs font-bold text-red-700 dark:text-red-400">
                          ¿Hay un problema con este trabajo?
                        </p>
                      </div>
                      <p className="text-xs text-red-600 dark:text-red-400">
                        Al reportar una disputa, el trabajo quedará pausado y podrás coordinar la resolución con el trabajador.
                      </p>
                      <div className="flex gap-2">
                        <button
                          onClick={() => setConfirmDisputeJobId(null)}
                          className="flex-1 border border-border text-muted-foreground text-xs font-bold py-2 rounded-xl hover:bg-muted transition"
                        >
                          Cancelar
                        </button>
                        <button
                          onClick={() => handleDispute(job)}
                          className="flex-1 bg-red-600 hover:bg-red-700 text-white text-xs font-black py-2 rounded-xl transition flex items-center justify-center gap-1"
                        >
                          <ShieldAlert className="w-3 h-3" />
                          Reportar problema
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Other actions */}
                  <div className="flex gap-2 flex-wrap">
                    {job.status === 'completed' && (
                      <button
                        onClick={() => setReviewJob(job)}
                        className="flex-1 text-xs bg-amber-500 text-white font-bold py-2.5 rounded-xl hover:bg-amber-600 transition flex items-center justify-center gap-1.5"
                      >
                        <Star className="w-3.5 h-3.5" />
                        Calificar trabajador
                      </button>
                    )}
                    {['pending', 'accepted', 'in_progress'].includes(job.status) && (
                      <button
                        onClick={() => handleCancel(job)}
                        className="flex-1 text-xs border border-destructive/50 text-destructive font-bold py-2.5 rounded-xl hover:bg-destructive hover:text-destructive-foreground transition"
                      >
                        Cancelar
                      </button>
                    )}
                    {['in_progress', 'finished'].includes(job.status) && confirmDisputeJobId !== job.id && (
                      <button
                        onClick={() => setConfirmDisputeJobId(job.id)}
                        className="px-3 py-2.5 border border-red-300 dark:border-red-800 text-red-600 dark:text-red-400 rounded-xl hover:bg-red-50 dark:hover:bg-red-950/30 transition"
                        title="Reportar un problema"
                      >
                        <ShieldAlert className="w-4 h-4" />
                      </button>
                    )}
                    {!isFinished && !isAccepted && pendingQuotes.length > 0 && (
                      <button
                        onClick={() => setExpandedJob(isExpanded ? null : job.id)}
                        className="px-3 py-2.5 border border-border rounded-xl text-muted-foreground hover:text-foreground transition"
                      >
                        {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                      </button>
                    )}
                  </div>
                </div>

                {/* Quotes expansion */}
                <AnimatePresence>
                  {!isFinished && !isAccepted && pendingQuotes.length > 0 && isExpanded && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.2 }}
                      className="overflow-hidden"
                    >
                      <div className="border-t border-border bg-muted/40 p-4 space-y-3">
                        <p className="text-xs font-black text-foreground uppercase tracking-wider flex items-center gap-1.5">
                          <FileText className="w-3.5 h-3.5 text-secondary" />
                          Presupuestos recibidos
                        </p>
                        {pendingQuotes.map((quote) => (
                          <div key={quote.id} className="bg-card rounded-2xl border border-border p-4 card-shadow">
                            <div className="flex items-center justify-between mb-2">
                              <div>
                                <p className="text-xl font-black text-foreground">
                                  {quote.currency} {quote.amount.toLocaleString()}
                                </p>
                                <p className="text-xs text-muted-foreground">{quote.worker_name}</p>
                              </div>
                              <div className="gradient-orange w-10 h-10 rounded-xl flex items-center justify-center">
                                <FileText className="w-5 h-5 text-white" />
                              </div>
                            </div>
                            {quote.sena_amount != null && quote.sena_amount > 0 && (
                              <div className="flex items-center gap-2 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 rounded-xl px-3 py-2 mb-2">
                                <Coins className="w-4 h-4 text-amber-600 flex-shrink-0" />
                                <div>
                                  <p className="text-xs font-bold text-amber-700 dark:text-amber-300">
                                    Seña requerida: {quote.currency} {quote.sena_amount.toLocaleString()}
                                  </p>
                                  <p className="text-xs text-amber-600 dark:text-amber-400">
                                    Saldo al finalizar: {quote.currency} {(quote.amount - quote.sena_amount).toLocaleString()}
                                  </p>
                                </div>
                              </div>
                            )}
                            {quote.message && (
                              <p className="text-sm text-muted-foreground bg-muted rounded-xl px-3 py-2 mb-3">
                                {quote.message}
                              </p>
                            )}
                            <div className="flex gap-2">
                              <button
                                onClick={() => handleAcceptQuote(quote)}
                                className="flex-1 bg-green-500 text-white text-sm font-black py-2.5 rounded-xl hover:bg-green-600 transition flex items-center justify-center gap-1.5 shadow-sm"
                              >
                                <ThumbsUp className="w-4 h-4" />
                                {t.acceptQuote}
                              </button>
                              <button
                                onClick={() => handleRejectQuote(quote)}
                                className="flex-1 border-2 border-red-200 dark:border-red-900 text-red-600 text-sm font-black py-2.5 rounded-xl hover:bg-red-50 dark:hover:bg-red-950/30 transition flex items-center justify-center gap-1.5"
                              >
                                <ThumbsDown className="w-4 h-4" />
                                {t.rejectQuote}
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            );
          })
        )}
      </div>

      <BottomNav t={t} />

      {reviewJob && (
        <ReviewModal
          jobId={reviewJob.id}
          workerId={reviewJob.worker_id}
          workerName={reviewJob.worker_name}
          onClose={() => setReviewJob(null)}
          onDone={() => setReviewJob(null)}
        />
      )}
    </div>
  );
}

// Reusable payment panel component for both seña and final payment
function PaymentPanel({
  label,
  amount,
  currency,
  payInfo,
  payMethod,
  copiedText,
  onCopy,
  onBack,
  onConfirm,
  confirmLabel,
}: {
  label: string;
  amount: number;
  currency: string;
  payInfo: WorkerPaymentInfo | undefined;
  payMethod: string;
  copiedText: string;
  onCopy: (text: string, label: string) => void;
  onBack: () => void;
  onConfirm: () => void;
  confirmLabel: string;
}) {
  const isCash = payMethod === 'cash';

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-muted border border-border rounded-2xl p-4 space-y-3"
    >
      <div className="flex items-center justify-between">
        <p className="text-sm font-black text-foreground">{label}</p>
        <p className="text-lg font-black text-primary">{currency} {amount.toLocaleString()}</p>
      </div>

      {isCash ? (
        <div className="bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 rounded-xl p-3 flex items-center gap-2">
          <Banknote className="w-4 h-4 text-amber-600 flex-shrink-0" />
          <p className="text-xs text-amber-700 dark:text-amber-300 font-semibold">
            Pago en efectivo — coordiná con el trabajador directamente.
          </p>
        </div>
      ) : (
        <div className="space-y-2">
          {/* MercadoPago button */}
          {payInfo?.mp_link && (
            <a
              href={payInfo.mp_link}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-3 w-full bg-[#009EE3] hover:brightness-95 active:scale-[0.98] transition-all rounded-xl px-4 py-3 shadow-md"
            >
              <MercadoPagoLogo className="w-8 h-8 flex-shrink-0" />
              <div className="flex-1 text-left">
                <p className="text-white font-black text-sm leading-tight">Pagar con MercadoPago</p>
                <p className="text-white/75 text-xs">Abre la app de MP automáticamente</p>
              </div>
              <ExternalLink className="w-4 h-4 text-white/70 flex-shrink-0" />
            </a>
          )}

          {/* Bank transfer */}
          {(payInfo?.alias || payInfo?.cbu) && (
            <div className="bg-card border border-border rounded-xl p-3 space-y-2">
              <p className="text-xs font-bold text-muted-foreground flex items-center gap-1.5">
                <CreditCard className="w-3.5 h-3.5" />
                Transferencia bancaria
              </p>
              {payInfo.alias && (
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs text-muted-foreground">Alias</p>
                    <p className="text-sm font-bold text-foreground">{payInfo.alias}</p>
                  </div>
                  <button onClick={() => onCopy(payInfo.alias!, 'Alias')} className="p-1.5 rounded-lg hover:bg-muted transition">
                    <Copy className="w-3.5 h-3.5 text-muted-foreground" />
                  </button>
                </div>
              )}
              {payInfo.cbu && (
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs text-muted-foreground">CBU / CVU</p>
                    <p className="text-xs font-mono font-bold text-foreground break-all">{payInfo.cbu}</p>
                  </div>
                  <button onClick={() => onCopy(payInfo.cbu!, 'CBU')} className="p-1.5 rounded-lg hover:bg-muted transition flex-shrink-0">
                    <Copy className="w-3.5 h-3.5 text-muted-foreground" />
                  </button>
                </div>
              )}
              {copiedText && (
                <p className="text-xs text-green-600 font-semibold text-center">{copiedText} copiado</p>
              )}
            </div>
          )}

          {!payInfo?.mp_link && !payInfo?.alias && !payInfo?.cbu && (
            <div className="bg-muted border border-border rounded-xl p-3 flex items-center gap-2">
              <CreditCard className="w-4 h-4 text-muted-foreground flex-shrink-0" />
              <p className="text-xs text-muted-foreground">
                El trabajador no cargó datos de pago aún. Coordiná directamente.
              </p>
            </div>
          )}
        </div>
      )}

      <div className="flex gap-2 pt-1">
        <button onClick={onBack} className="flex-1 border border-border text-muted-foreground text-sm font-bold py-2.5 rounded-xl hover:bg-card transition">
          Volver
        </button>
        <button
          onClick={onConfirm}
          className="flex-1 bg-green-500 text-white text-sm font-black py-2.5 rounded-xl hover:bg-green-600 transition flex items-center justify-center gap-1.5 shadow-sm"
        >
          <CheckCircle className="w-4 h-4" />
          {confirmLabel}
        </button>
      </div>
    </motion.div>
  );
}
