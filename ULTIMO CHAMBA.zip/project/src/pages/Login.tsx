import { useState } from 'react';
import { Mail, Lock, User, ArrowRight, Loader2 } from 'lucide-react';
import { useAuth } from '@/lib/AuthContext';

export default function Login() {
  const { signIn, signUp } = useAuth();
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [acceptedTerms, setAcceptedTerms] = useState(false);
  const [showTermsError, setShowTermsError] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!isLogin && !acceptedTerms) {
      setShowTermsError(true);
      return;
    }
    setShowTermsError(false);
    setLoading(true);

    try {
      if (isLogin) {
        const { error: err } = await signIn(email, password);
        if (err) throw err;
        // onAuthStateChange in AuthContext handles the rest
      } else {
        const { error: err } = await signUp(email, password, fullName);
        if (err) throw err;
        // onAuthStateChange → fetchProfile → needsRoleSelection=true → RolePicker shown by App.tsx
      }
    } catch (err: any) {
      setError(err.message || 'Ocurrió un error. Intentá de nuevo.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4">
      <div className="flex items-center justify-center gap-3 mb-8">
        <img src="/Gemini_Generated_Image_qvyypfqvyypfqvyy.png" alt="Chamba" className="h-20 w-auto object-contain" />
        <img src="/Gemini_Generated_Image_jhvq6ujhvq6ujhvq.png" alt="Chamba" className="h-14 w-auto object-contain" />
      </div>

      <div className="w-full max-w-md">
        <div className="bg-card rounded-3xl border border-border card-shadow-lg p-6">
          {/* Tab switcher */}
          <div className="flex bg-muted rounded-xl p-1 mb-6">
            <button
              onClick={() => { setIsLogin(true); setError(''); setShowTermsError(false); }}
              className={`flex-1 py-2.5 text-sm font-bold rounded-lg transition-all ${
                isLogin ? 'bg-card shadow text-foreground' : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              Iniciar sesión
            </button>
            <button
              onClick={() => { setIsLogin(false); setError(''); setShowTermsError(false); }}
              className={`flex-1 py-2.5 text-sm font-bold rounded-lg transition-all ${
                !isLogin ? 'bg-card shadow text-foreground' : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              Registrarse
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {!isLogin && (
              <div>
                <label className="block text-sm font-bold text-foreground mb-1.5">Nombre completo</label>
                <div className="relative">
                  <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <input
                    type="text"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="Juan Pérez"
                    required
                    className="w-full pl-10 pr-4 py-3 bg-muted border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary transition"
                  />
                </div>
              </div>
            )}

            <div>
              <label className="block text-sm font-bold text-foreground mb-1.5">Email</label>
              <div className="relative">
                <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="tu@email.com"
                  required
                  className="w-full pl-10 pr-4 py-3 bg-muted border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary transition"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-bold text-foreground mb-1.5">Contraseña</label>
              <div className="relative">
                <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  required
                  minLength={6}
                  className="w-full pl-10 pr-4 py-3 bg-muted border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary transition"
                />
              </div>
            </div>

            {!isLogin && (
              <div>
                <button
                  type="button"
                  onClick={() => { setAcceptedTerms((v) => !v); setShowTermsError(false); }}
                  className={`w-full flex items-start gap-3 p-3.5 rounded-2xl border-2 text-left transition-all ${
                    showTermsError
                      ? 'border-destructive bg-destructive/5'
                      : acceptedTerms
                        ? 'border-primary bg-primary/5'
                        : 'border-border bg-muted hover:border-primary/40'
                  }`}
                >
                  <div className={`mt-0.5 w-5 h-5 rounded-md border-2 flex-shrink-0 flex items-center justify-center transition-all ${
                    acceptedTerms ? 'bg-primary border-primary' : showTermsError ? 'border-destructive' : 'border-muted-foreground/40'
                  }`}>
                    {acceptedTerms && (
                      <svg className="w-3 h-3 text-white" viewBox="0 0 12 12" fill="none">
                        <path d="M2 6l3 3 5-5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                    )}
                  </div>
                  <p className={`text-xs leading-relaxed ${showTermsError ? 'text-destructive' : 'text-muted-foreground'}`}>
                    Leí y acepto los{' '}
                    <span
                      onClick={(e) => e.stopPropagation()}
                      className="font-bold underline text-primary cursor-pointer hover:text-primary/80"
                    >
                      Términos y Condiciones
                    </span>
                    {' '}y la{' '}
                    <span
                      onClick={(e) => e.stopPropagation()}
                      className="font-bold underline text-primary cursor-pointer hover:text-primary/80"
                    >
                      Política de Privacidad
                    </span>
                    {' '}de Chamba.
                  </p>
                </button>
                {showTermsError && (
                  <p className="text-xs text-destructive font-semibold mt-1.5 ml-1">
                    Debes aceptar los términos para continuar.
                  </p>
                )}
              </div>
            )}

            {error && (
              <div className="text-sm px-4 py-3 rounded-xl bg-destructive/10 text-destructive border border-destructive/20">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full gradient-orange text-white font-black py-4 rounded-2xl shadow-lg glow-secondary hover:brightness-95 active:scale-[0.98] transition-all disabled:opacity-60 flex items-center justify-center gap-2 mt-2"
            >
              {loading ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <>
                  {isLogin ? 'Entrar' : 'Crear cuenta'}
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>
        </div>

        <p className="text-center text-xs text-muted-foreground mt-4">
          {isLogin ? 'Al iniciar sesión aceptás los términos de servicio de Chamba.' : ''}
        </p>
      </div>
    </div>
  );
}
