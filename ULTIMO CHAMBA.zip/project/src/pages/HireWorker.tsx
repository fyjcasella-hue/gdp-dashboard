import { useState, useEffect, useRef } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { ArrowLeft, Send, CheckCircle, Banknote, FileText, CreditCard, ImagePlus, X, AlertCircle } from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/lib/AuthContext';
import { sendEmail } from '@/lib/sendEmail';
import { useTranslation } from '@/components/chamba/i18n';
import type { Worker } from '@/components/chamba/geo';
import { getWorkerServices } from '@/components/chamba/geo';

const MAX_IMAGES = 5;
const MAX_SIZE_MB = 10;

interface ImageFile {
  file: File;
  preview: string;
}

export default function HireWorker() {
  const t = useTranslation();
  const navigate = useNavigate();
  const { state } = useLocation();
  const worker = state?.worker as Worker | undefined;
  const { user, profile } = useAuth();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const workerServices = worker ? getWorkerServices(worker) : [];
  const [selectedService, setSelectedService] = useState('');
  const [description, setDescription] = useState('');
  const [payMethod, setPayMethod] = useState<'transfer' | 'cash'>('transfer');
  const [images, setImages] = useState<ImageFile[]>([]);
  const [imageError, setImageError] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);
  const [submitError, setSubmitError] = useState('');

  useEffect(() => {
    if (!worker) navigate(-1);
    if (!user) navigate('/Home');
    if (worker) setSelectedService(getWorkerServices(worker)[0] || '');
  }, [worker, user, navigate]);

  // Clean up object URLs on unmount
  useEffect(() => {
    return () => { images.forEach((img) => URL.revokeObjectURL(img.preview)); };
  }, [images]);

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    setImageError('');
    const files = Array.from(e.target.files || []);
    if (!files.length) return;

    const remaining = MAX_IMAGES - images.length;
    if (remaining <= 0) {
      setImageError(`Máximo ${MAX_IMAGES} imágenes.`);
      return;
    }

    const valid: ImageFile[] = [];
    for (const file of files.slice(0, remaining)) {
      if (file.size > MAX_SIZE_MB * 1024 * 1024) {
        setImageError(`"${file.name}" supera los ${MAX_SIZE_MB} MB.`);
        continue;
      }
      valid.push({ file, preview: URL.createObjectURL(file) });
    }

    setImages((prev) => [...prev, ...valid]);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const removeImage = (index: number) => {
    setImages((prev) => {
      URL.revokeObjectURL(prev[index].preview);
      return prev.filter((_, i) => i !== index);
    });
  };

  const uploadImages = async (): Promise<string[]> => {
    const urls: string[] = [];
    for (const img of images) {
      const ext = img.file.name.split('.').pop() || 'jpg';
      const path = `${user!.id}/${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
      const { error } = await supabase.storage
        .from('job-images')
        .upload(path, img.file, { contentType: img.file.type, upsert: false });
      if (!error) {
        const { data } = supabase.storage.from('job-images').getPublicUrl(path);
        urls.push(data.publicUrl);
      }
    }
    return urls;
  };

  const handleSubmit = async () => {
    if (!description.trim() || !user || !worker) return;
    setSubmitting(true);
    setSubmitError('');

    let imageUrls: string[] = [];
    if (images.length > 0) {
      imageUrls = await uploadImages();
    }

    const { error } = await supabase.from('jobs').insert({
      client_email: user.email,
      client_name: profile?.full_name || user.email,
      worker_id: worker.id,
      worker_name: worker.name,
      service: selectedService || worker.service,
      description: description.trim(),
      images: imageUrls,
      amount: null,
      payment_method: payMethod,
      status: 'pending',
      payment_status: 'unpaid',
    });

    if (!error) {
      setDone(true);
      if (worker.user_email) {
        sendEmail('job_request', worker.user_email, {
          service: selectedService || worker.service,
          description: description.trim(),
          client_name: profile?.full_name || user.email,
          client_email: user.email,
          payment_method: payMethod,
        });
      }
    } else {
      setSubmitError('No se pudo enviar la solicitud. Intentá de nuevo.');
    }
    setSubmitting(false);
  };

  if (done) {
    return (
      <div className="min-h-screen bg-background max-w-lg mx-auto flex flex-col items-center justify-center p-8 text-center">
        <div className="w-24 h-24 bg-gradient-to-br from-green-400 to-green-600 rounded-full flex items-center justify-center mb-6 shadow-lg shadow-green-200">
          <CheckCircle className="w-12 h-12 text-white" />
        </div>
        <h2 className="text-2xl font-black text-foreground mb-2">¡Solicitud enviada!</h2>
        <p className="text-muted-foreground mb-6">
          Tu solicitud fue enviada a <strong className="text-foreground">{worker?.name}</strong>.
          Recibirás su presupuesto pronto.
        </p>

        <div className="w-full bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800 rounded-2xl p-4 text-left mb-6">
          <div className="flex items-center gap-2 mb-2">
            <FileText className="w-5 h-5 text-blue-600" />
            <p className="font-bold text-blue-700 dark:text-blue-400">¿Qué pasa ahora?</p>
          </div>
          <ol className="space-y-1.5 text-sm text-blue-700 dark:text-blue-400">
            <li>1. El trabajador recibe tu descripción del trabajo</li>
            <li>2. Te envía un presupuesto con el monto (y seña si lo requiere)</li>
            <li>3. Vos aceptás o rechazás desde "Mis trabajos"</li>
            <li>4. Al finalizar el trabajo, pagás el total acordado</li>
          </ol>
        </div>

        <button
          onClick={() => navigate('/Jobs')}
          className="w-full bg-secondary text-secondary-foreground font-bold py-4 rounded-2xl shadow-lg shadow-secondary/30 hover:brightness-95 transition mb-3"
        >
          Ver mis trabajos →
        </button>
        <button onClick={() => navigate('/Home')} className="text-sm text-muted-foreground hover:text-foreground transition">
          Volver al inicio
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background max-w-lg mx-auto pb-8">
      <div className="sticky top-0 z-10 bg-card/95 backdrop-blur border-b border-border px-4 py-3 flex items-center gap-3 shadow-sm">
        <button onClick={() => navigate(-1)} className="p-2 rounded-xl hover:bg-muted transition-colors">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h2 className="font-bold text-lg text-foreground">{t.hireNow}</h2>
      </div>

      <div className="p-4 space-y-4">
        {/* Worker card */}
        <div className="bg-card rounded-2xl border border-border p-4 flex items-center gap-4 shadow-sm">
          <img
            src={worker?.avatar || `https://placehold.co/56x56/0d9488/ffffff?text=${worker?.name?.charAt(0)}`}
            alt={worker?.name}
            className="w-14 h-14 rounded-2xl object-cover border-2 border-secondary flex-shrink-0"
            onError={(e) => { e.currentTarget.src = 'https://placehold.co/56x56/ccc/fff?text=W'; }}
          />
          <div className="flex-1 min-w-0">
            <p className="font-black text-foreground text-base">{worker?.name}</p>
            {workerServices.length === 1 ? (
              <p className="text-sm text-secondary font-semibold">{workerServices[0]}</p>
            ) : (
              <div className="flex flex-wrap gap-1 mt-1">
                {workerServices.slice(0, 3).map((s) => (
                  <span key={s} className="text-[10px] font-bold bg-secondary/10 text-secondary px-2 py-0.5 rounded-full">
                    {s}
                  </span>
                ))}
                {workerServices.length > 3 && (
                  <span className="text-[10px] font-bold bg-muted text-muted-foreground px-2 py-0.5 rounded-full">
                    +{workerServices.length - 3}
                  </span>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Service selector — only if worker has multiple services */}
        {workerServices.length > 1 && (
          <div className="bg-card rounded-2xl border border-border p-4 shadow-sm">
            <p className="text-sm font-black text-foreground mb-3">¿Para qué servicio es?</p>
            <div className="flex flex-wrap gap-2">
              {workerServices.map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => setSelectedService(s)}
                  className={`text-xs font-bold px-3 py-2 rounded-xl border transition-all ${
                    selectedService === s
                      ? 'bg-primary text-white border-primary shadow-sm'
                      : 'bg-muted border-border text-foreground hover:border-primary/50'
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Description + Images */}
        <div className="bg-card rounded-2xl border border-border p-4 shadow-sm space-y-4">
          {/* Description */}
          <div>
            <label className="block mb-2 text-sm font-bold text-foreground">
              {t.jobDescription} <span className="text-destructive">*</span>
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={4}
              placeholder="Describí en detalle qué necesitás que haga el trabajador..."
              className="w-full px-4 py-3 bg-muted border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary resize-none transition"
            />
            <p className="text-xs text-muted-foreground mt-1.5">
              Cuanto más detalle, mejor será el presupuesto que recibirás.
            </p>
          </div>

          {/* Image upload */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-sm font-bold text-foreground flex items-center gap-1.5">
                <ImagePlus className="w-4 h-4 text-primary" />
                Fotos del trabajo
                <span className="text-xs font-normal text-muted-foreground ml-1">(opcional)</span>
              </label>
              <span className="text-xs text-muted-foreground">{images.length}/{MAX_IMAGES}</span>
            </div>

            {/* Thumbnails grid */}
            {images.length > 0 && (
              <div className="grid grid-cols-3 gap-2 mb-3">
                {images.map((img, i) => (
                  <div key={i} className="relative group aspect-square rounded-xl overflow-hidden border border-border bg-muted">
                    <img
                      src={img.preview}
                      alt={`Foto ${i + 1}`}
                      className="w-full h-full object-cover"
                    />
                    <button
                      onClick={() => removeImage(i)}
                      className="absolute top-1 right-1 w-6 h-6 bg-black/60 hover:bg-black/80 rounded-full flex items-center justify-center transition-opacity opacity-0 group-hover:opacity-100"
                    >
                      <X className="w-3.5 h-3.5 text-white" />
                    </button>
                  </div>
                ))}
                {/* Add more slot */}
                {images.length < MAX_IMAGES && (
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="aspect-square rounded-xl border-2 border-dashed border-border hover:border-primary/50 bg-muted flex flex-col items-center justify-center gap-1 transition-colors"
                  >
                    <ImagePlus className="w-5 h-5 text-muted-foreground" />
                    <span className="text-[10px] text-muted-foreground font-semibold">Agregar</span>
                  </button>
                )}
              </div>
            )}

            {/* Upload button (when no images yet) */}
            {images.length === 0 && (
              <button
                onClick={() => fileInputRef.current?.click()}
                className="w-full border-2 border-dashed border-border hover:border-primary/50 rounded-xl py-5 flex flex-col items-center gap-2 transition-colors group"
              >
                <div className="w-10 h-10 bg-primary/10 group-hover:bg-primary/15 rounded-xl flex items-center justify-center transition-colors">
                  <ImagePlus className="w-5 h-5 text-primary" />
                </div>
                <div className="text-center">
                  <p className="text-sm font-bold text-foreground">Subir fotos</p>
                  <p className="text-xs text-muted-foreground">JPG, PNG, WEBP — hasta {MAX_SIZE_MB} MB c/u</p>
                </div>
              </button>
            )}

            {imageError && (
              <div className="flex items-center gap-2 mt-2 text-xs text-destructive">
                <AlertCircle className="w-3.5 h-3.5 flex-shrink-0" />
                {imageError}
              </div>
            )}

            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              multiple
              className="hidden"
              onChange={handleImageSelect}
            />
          </div>
        </div>

        {/* Quote info */}
        <div className="bg-gradient-to-br from-primary/8 to-primary/5 border border-primary/20 rounded-2xl p-4 flex items-start gap-3">
          <div className="w-9 h-9 bg-primary/15 rounded-xl flex items-center justify-center flex-shrink-0 mt-0.5">
            <FileText className="w-5 h-5 text-primary" />
          </div>
          <div>
            <p className="font-bold text-foreground text-sm mb-1">El trabajador te enviará un presupuesto</p>
            <p className="text-xs text-muted-foreground leading-relaxed">
              Puede incluir una seña para asegurar el trabajo. Podrás aceptarlo o rechazarlo antes de comenzar.
            </p>
          </div>
        </div>

        {/* Payment method */}
        <div className="bg-card rounded-2xl border border-border p-4 shadow-sm">
          <p className="text-sm font-bold text-foreground mb-3">{t.payMethod}</p>
          <div className="space-y-3">
            {/* Transfer */}
            <button
              onClick={() => setPayMethod('transfer')}
              className={`w-full flex items-center gap-4 p-4 rounded-2xl border-2 text-left transition-all ${
                payMethod === 'transfer'
                  ? 'border-primary bg-primary/5 dark:bg-primary/10'
                  : 'border-border bg-muted hover:border-primary/40'
              }`}
            >
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 transition-colors ${
                payMethod === 'transfer' ? 'gradient-brand' : 'bg-muted-foreground/20'
              }`}>
                <CreditCard className={`w-5 h-5 ${payMethod === 'transfer' ? 'text-white' : 'text-muted-foreground'}`} />
              </div>
              <div className="flex-1 min-w-0">
                <p className={`font-bold text-sm ${payMethod === 'transfer' ? 'text-primary' : 'text-foreground'}`}>
                  Transferencia bancaria
                </p>
                <p className="text-xs text-muted-foreground mt-0.5">
                  Pagás por alias o CBU al finalizar el trabajo
                </p>
              </div>
              <div className={`w-5 h-5 rounded-full border-2 flex-shrink-0 flex items-center justify-center ${
                payMethod === 'transfer' ? 'border-primary' : 'border-muted-foreground/40'
              }`}>
                {payMethod === 'transfer' && <div className="w-2.5 h-2.5 rounded-full bg-primary" />}
              </div>
            </button>

            {/* Cash */}
            <button
              onClick={() => setPayMethod('cash')}
              className={`w-full flex items-center gap-4 p-4 rounded-2xl border-2 text-left transition-all ${
                payMethod === 'cash'
                  ? 'border-amber-500 bg-amber-50 dark:bg-amber-950/20'
                  : 'border-border bg-muted hover:border-amber-300'
              }`}
            >
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 transition-colors ${
                payMethod === 'cash' ? 'bg-amber-500' : 'bg-muted-foreground/20'
              }`}>
                <Banknote className={`w-5 h-5 ${payMethod === 'cash' ? 'text-white' : 'text-muted-foreground'}`} />
              </div>
              <div className="flex-1 min-w-0">
                <p className={`font-bold text-sm ${payMethod === 'cash' ? 'text-amber-700 dark:text-amber-400' : 'text-foreground'}`}>
                  {t.cashPayment}
                </p>
                <p className="text-xs text-muted-foreground mt-0.5">
                  Acordás el pago en efectivo directamente con el trabajador
                </p>
              </div>
              <div className={`w-5 h-5 rounded-full border-2 flex-shrink-0 flex items-center justify-center ${
                payMethod === 'cash' ? 'border-amber-500' : 'border-muted-foreground/40'
              }`}>
                {payMethod === 'cash' && <div className="w-2.5 h-2.5 rounded-full bg-amber-500" />}
              </div>
            </button>
          </div>
        </div>

        {submitError && (
          <div className="text-sm px-4 py-3 rounded-xl bg-destructive/10 text-destructive border border-destructive/20">
            {submitError}
          </div>
        )}

        {/* Submit */}
        <button
          onClick={handleSubmit}
          disabled={submitting || !description.trim()}
          className="w-full bg-secondary text-secondary-foreground font-black py-4 rounded-2xl text-base shadow-lg shadow-secondary/30 hover:brightness-95 active:scale-[0.98] transition-all disabled:opacity-50 flex items-center justify-center gap-2"
        >
          {submitting ? (
            <div className="flex items-center gap-2">
              <div className="w-5 h-5 border-2 border-secondary-foreground/30 border-t-secondary-foreground rounded-full animate-spin" />
              {images.length > 0 ? 'Subiendo imágenes...' : 'Enviando...'}
            </div>
          ) : (
            <>
              <Send className="w-5 h-5" />
              Solicitar presupuesto
              {images.length > 0 && (
                <span className="bg-secondary-foreground/20 text-secondary-foreground text-xs font-bold px-2 py-0.5 rounded-full">
                  {images.length} foto{images.length > 1 ? 's' : ''}
                </span>
              )}
            </>
          )}
        </button>
      </div>
    </div>
  );
}
