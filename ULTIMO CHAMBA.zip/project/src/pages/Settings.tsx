import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ArrowLeft, Camera, Save, LogOut, Wrench, User, Plus, X, Images, CreditCard, ArrowLeftRight,
} from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/lib/AuthContext';
import { useTranslation } from '@/components/chamba/i18n';
import { WORLD_COUNTRIES, WORKER_SERVICES, SERVICE_CATEGORIES } from '@/components/chamba/geo';
import BottomNav from '@/components/chamba/BottomNav';
import LanguagePicker from '@/components/chamba/LanguagePicker';
import MercadoPagoLogo from '@/components/chamba/MercadoPagoLogo';
import RoleSwitcher from '@/components/chamba/RoleSwitcher';

export default function Settings() {
  const t = useTranslation();
  const navigate = useNavigate();
  const { user, profile, signOut, updateProfile, isLoading } = useAuth();

  const [workerProfileId, setWorkerProfileId] = useState<string | null>(null);
  const [name, setName] = useState('');
  const [bio, setBio] = useState('');
  const [services, setServices] = useState<string[]>([WORKER_SERVICES[0]]);
  const [country, setCountry] = useState('');
  const [province, setProvince] = useState('');
  const [city, setCity] = useState('');
  const [available, setAvailable] = useState(true);
  const [avatar, setAvatar] = useState('');
  const [portfolio, setPortfolio] = useState<string[]>([]);
  const [alias, setAlias] = useState('');
  const [cbu, setCbu] = useState('');
  const [mpLink, setMpLink] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [saveError, setSaveError] = useState('');
  const [uploadingPortfolio, setUploadingPortfolio] = useState(false);
  const [savedMsg, setSavedMsg] = useState('');
  const [pendingRole, setPendingRole] = useState<'client' | 'worker' | null>(null);
  const [switchingRole, setSwitchingRole] = useState(false);
  const portfolioInputRef = useRef<HTMLInputElement>(null);
  const isWorker = profile?.role === 'worker';

  useEffect(() => {
    if (!isLoading && !user) { navigate('/Home'); return; }
    if (profile) { setName(profile.full_name || ''); setAvatar(profile.avatar || ''); }
    if (user && isWorker) {
      (async () => {
        const { data } = await supabase
          .from('workers')
          .select('*')
          .eq('user_email', user.email)
          .maybeSingle();
        if (data) {
          setWorkerProfileId(data.id);
          setBio(data.bio || '');
          setServices(
            data.services && data.services.length > 0
              ? data.services
              : data.service ? [data.service] : [WORKER_SERVICES[0]]
          );
          setCountry(data.zone_country || '');
          setProvince(data.zone_province || '');
          setCity(data.zone_locality || '');
          setAvailable(data.available !== false);
          setPortfolio(data.portfolio || []);
          setAlias(data.alias || '');
          setCbu(data.cbu || '');
          setMpLink(data.mp_link || '');
        }
      })();
    }
  }, [user, profile, isWorker, isLoading, navigate]);

  const handleAvatarChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;
    const ext = file.name.split('.').pop();
    const path = `${user.id}/avatar.${ext}`;
    const { error } = await supabase.storage.from('avatars').upload(path, file, { upsert: true });
    if (!error) {
      const { data: urlData } = supabase.storage.from('avatars').getPublicUrl(path);
      setAvatar(urlData.publicUrl);
    }
  };

  const handlePortfolioUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || !user) return;
    setUploadingPortfolio(true);
    const newUrls: string[] = [];
    for (const file of Array.from(files)) {
      const ext = file.name.split('.').pop();
      const path = `${user.id}/portfolio/${Date.now()}_${Math.random().toString(36).slice(2)}.${ext}`;
      const { error } = await supabase.storage.from('avatars').upload(path, file, { upsert: false });
      if (!error) {
        const { data: urlData } = supabase.storage.from('avatars').getPublicUrl(path);
        newUrls.push(urlData.publicUrl);
      }
    }
    setPortfolio((prev) => [...prev, ...newUrls]);
    setUploadingPortfolio(false);
    if (portfolioInputRef.current) portfolioInputRef.current.value = '';
  };

  const removePortfolioPhoto = (url: string) => {
    setPortfolio((prev) => prev.filter((u) => u !== url));
  };

  const handleRoleSwitch = async () => {
    if (!pendingRole) return;
    setSwitchingRole(true);
    await updateProfile({ role: pendingRole });
    setPendingRole(null);
    setSwitchingRole(false);
    navigate(pendingRole === 'worker' ? '/WorkerDashboard' : '/Home');
  };

  const handleSave = async () => {
    if (!user || !profile) return;

    // CBU validation: must be exactly 22 digits if provided
    const cbuVal = cbu.trim();
    if (cbuVal && !/^\d{22}$/.test(cbuVal)) {
      setSaveError('El CBU/CVU debe tener exactamente 22 dígitos numéricos.');
      return;
    }

    setSaveError('');
    setIsSaving(true);

    try {
      await updateProfile({ avatar, full_name: name });
      if (isWorker) {
        const data = {
          user_id: user.id,
          user_email: user.email,
          name,
          bio,
          service: services[0] || WORKER_SERVICES[0],
          services,
          zone_country: country,
          zone_province: province,
          zone_locality: city,
          avatar,
          available,
          portfolio,
          alias: alias.trim() || null,
          cbu: cbuVal || null,
          mp_link: mpLink.trim() || null,
        };
        let dbError;
        if (workerProfileId) {
          const res = await supabase.from('workers').update(data).eq('id', workerProfileId);
          dbError = res.error;
        } else {
          const res = await supabase.from('workers').insert(data).select('id').single();
          dbError = res.error;
          if (res.data) setWorkerProfileId(res.data.id);
        }
        if (dbError) throw new Error(dbError.message);
      }
      setSavedMsg(t.savedOk);
      setTimeout(() => setSavedMsg(''), 3000);
    } catch {
      setSaveError('No se pudieron guardar los cambios. Intentá de nuevo.');
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen bg-background">
        <div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background max-w-lg mx-auto">
      <div className="sticky top-0 z-10 bg-card/95 backdrop-blur-xl border-b border-border px-4 py-3 flex items-center justify-between shadow-sm">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate(-1)} className="p-2 rounded-xl hover:bg-muted transition-colors">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h2 className="font-black text-foreground text-lg">{t.profileSettings}</h2>
        </div>
        <LanguagePicker />
      </div>

      <div className="p-4 pb-36 space-y-4">
        {/* Role switcher */}
        <div className="bg-card rounded-2xl border border-border p-4 card-shadow space-y-3">
          <div className="flex items-center gap-2 mb-1">
            <ArrowLeftRight className="w-4 h-4 text-muted-foreground" />
            <p className="text-sm font-black text-foreground">Modo activo</p>
            <span className={`ml-auto text-xs font-bold px-2.5 py-1 rounded-full ${
              isWorker ? 'bg-primary/10 text-primary' : 'bg-secondary/10 text-secondary'
            }`}>
              {isWorker ? 'Trabajador' : 'Cliente'}
            </span>
          </div>
          <RoleSwitcher
            role={profile?.role === 'worker' ? 'worker' : 'client'}
            onChange={(newRole) => {
              if (newRole !== profile?.role) setPendingRole(newRole);
            }}
          />
          <p className="text-xs text-muted-foreground text-center">
            {isWorker
              ? 'Cambiá a modo cliente para buscar y contratar profesionales'
              : 'Cambiá a modo trabajador para ofrecer tus servicios'}
          </p>
        </div>

        {/* Role change confirmation modal */}
        {pendingRole && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
            <div className="bg-card rounded-3xl border border-border p-6 w-full max-w-sm card-shadow-lg space-y-4">
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-2xl flex items-center justify-center ${
                  pendingRole === 'worker' ? 'gradient-brand' : 'gradient-orange'
                }`}>
                  {pendingRole === 'worker'
                    ? <Wrench className="w-5 h-5 text-white" />
                    : <User className="w-5 h-5 text-white" />
                  }
                </div>
                <div>
                  <p className="font-black text-foreground">
                    Cambiar a modo {pendingRole === 'worker' ? 'Trabajador' : 'Cliente'}
                  </p>
                  <p className="text-xs text-muted-foreground">Podés volver cuando quieras</p>
                </div>
              </div>
              <p className="text-sm text-muted-foreground leading-relaxed">
                {pendingRole === 'worker'
                  ? 'Pasarás a modo trabajador. Los clientes podrán ver tu perfil y enviarte solicitudes de trabajo.'
                  : 'Pasarás a modo cliente. Tu perfil de trabajador se conserva — podés volver a activarlo cuando quieras.'}
              </p>
              <div className="flex gap-3">
                <button
                  onClick={() => setPendingRole(null)}
                  className="flex-1 border border-border text-muted-foreground font-bold py-3 rounded-2xl hover:bg-muted transition text-sm"
                >
                  Cancelar
                </button>
                <button
                  onClick={handleRoleSwitch}
                  disabled={switchingRole}
                  className={`flex-1 text-white font-black py-3 rounded-2xl hover:brightness-95 transition text-sm flex items-center justify-center gap-2 ${
                    pendingRole === 'worker' ? 'gradient-brand' : 'gradient-orange'
                  } disabled:opacity-60`}
                >
                  {switchingRole ? (
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : (
                    'Confirmar'
                  )}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Personal data */}
        <div className="bg-card rounded-2xl border border-border p-5 card-shadow">
          <h3 className="font-black text-foreground mb-4 pb-2 border-b border-border text-sm flex items-center gap-2">
            <User className="w-4 h-4 text-muted-foreground" />
            Datos Personales
          </h3>
          <div className="flex flex-col items-center mb-5">
            <div className="relative">
              <div className="w-24 h-24 rounded-2xl border-4 border-secondary/30 overflow-hidden shadow-lg">
                <img
                  src={avatar || `https://placehold.co/96x96/0d9488/ffffff?text=${name?.charAt(0) || 'U'}`}
                  alt="avatar"
                  className="w-full h-full object-cover"
                  onError={(e) => { e.currentTarget.src = 'https://placehold.co/96x96/ccc/333?text=U'; }}
                />
              </div>
              <label className="absolute -bottom-2 -right-2 gradient-orange text-white rounded-full p-2 cursor-pointer shadow-lg hover:brightness-95 transition">
                <Camera className="w-4 h-4" />
                <input type="file" accept="image/*" className="hidden" onChange={handleAvatarChange} />
              </label>
            </div>
            <p className="text-xs text-muted-foreground mt-4">{user?.email}</p>
          </div>
          <label className="block">
            <span className="text-sm font-bold text-foreground">{t.fullName}</span>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="mt-1.5 w-full px-4 py-3 bg-muted border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary transition"
            />
          </label>
        </div>

        {/* Professional data — workers only */}
        {isWorker && (
          <>
            <div className="bg-card rounded-2xl border border-border p-5 card-shadow">
              <h3 className="font-black text-foreground mb-4 pb-2 border-b border-border text-sm flex items-center gap-2">
                <Wrench className="w-4 h-4 text-muted-foreground" />
                Datos Profesionales
              </h3>

              <div className="flex items-center justify-between mb-5 bg-muted rounded-2xl px-4 py-3">
                <div>
                  <p className="text-sm font-bold text-foreground">Disponible ahora</p>
                  <p className="text-xs text-muted-foreground mt-0.5">Los clientes verán que podés trabajar</p>
                </div>
                <button
                  onClick={() => setAvailable((a) => !a)}
                  className={`relative w-12 h-6 rounded-full transition-colors ${available ? 'bg-green-500' : 'bg-muted-foreground/30'}`}
                >
                  <div className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow transition-transform ${available ? 'translate-x-7' : 'translate-x-1'}`} />
                </button>
              </div>

              <div className="space-y-4">
                <label className="block">
                  <span className="text-sm font-bold text-foreground">{t.bioLabel}</span>
                  <textarea
                    value={bio}
                    onChange={(e) => setBio(e.target.value)}
                    maxLength={250}
                    rows={3}
                    className="mt-1.5 w-full px-4 py-3 bg-muted border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary resize-none transition"
                  />
                  <p className="text-xs text-muted-foreground text-right mt-1">{bio.length}/250</p>
                </label>

                {/* Multi-service selector */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-bold text-foreground">Servicios que ofrecés</span>
                    <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${
                      services.length >= 5 ? 'bg-amber-100 dark:bg-amber-950/40 text-amber-700 dark:text-amber-400' : 'bg-muted text-muted-foreground'
                    }`}>
                      {services.length}/5
                    </span>
                  </div>
                  {services.length === 0 && (
                    <p className="text-xs text-destructive font-semibold mb-2">Seleccioná al menos un servicio</p>
                  )}
                  <div className="space-y-3">
                    {SERVICE_CATEGORIES.map((cat) => {
                      const catSelected = cat.services.filter((s) => services.includes(s));
                      return (
                        <div key={cat.label}>
                          <p className="text-xs font-black text-muted-foreground uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                            {cat.label}
                            {catSelected.length > 0 && (
                              <span className="text-primary font-bold normal-case tracking-normal">· {catSelected.length}</span>
                            )}
                          </p>
                          <div className="flex flex-wrap gap-1.5">
                            {cat.services.map((s) => {
                              const selected = services.includes(s);
                              const atMax = services.length >= 5 && !selected;
                              return (
                                <button
                                  key={s}
                                  type="button"
                                  disabled={atMax}
                                  onClick={() => {
                                    if (selected) {
                                      if (services.length > 1) setServices((prev) => prev.filter((x) => x !== s));
                                    } else if (!atMax) {
                                      setServices((prev) => [...prev, s]);
                                    }
                                  }}
                                  className={`text-xs px-2.5 py-1.5 rounded-xl font-semibold border transition-all duration-150 ${
                                    selected
                                      ? 'bg-primary text-white border-primary shadow-sm'
                                      : atMax
                                        ? 'bg-muted border-border text-muted-foreground/40 cursor-not-allowed'
                                        : 'bg-card border-border text-foreground hover:border-primary/50 hover:text-primary'
                                  }`}
                                >
                                  {s}
                                </button>
                              );
                            })}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div>
                  <p className="text-sm font-bold text-foreground mb-2">Zona de trabajo</p>
                  <div className="grid grid-cols-2 gap-3 mb-3">
                    <label className="block">
                      <span className="text-xs font-semibold text-muted-foreground">{t.country}</span>
                      <input
                        type="text"
                        value={country}
                        onChange={(e) => setCountry(e.target.value)}
                        list="settings-countries"
                        placeholder="Argentina..."
                        className="mt-1 w-full px-3 py-3 bg-muted border border-border rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-primary transition"
                      />
                      <datalist id="settings-countries">
                        {WORLD_COUNTRIES.map((c) => <option key={c} value={c} />)}
                      </datalist>
                    </label>
                    <label className="block">
                      <span className="text-xs font-semibold text-muted-foreground">Provincia / Estado</span>
                      <input
                        type="text"
                        value={province}
                        onChange={(e) => setProvince(e.target.value)}
                        placeholder="Córdoba..."
                        className="mt-1 w-full px-3 py-3 bg-muted border border-border rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-primary transition"
                      />
                    </label>
                  </div>
                  <label className="block">
                    <span className="text-xs font-semibold text-muted-foreground">{t.city}</span>
                    <input
                      type="text"
                      value={city}
                      onChange={(e) => setCity(e.target.value)}
                      placeholder="Buenos Aires..."
                      className="mt-1.5 w-full px-3 py-3 bg-muted border border-border rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-primary transition"
                    />
                  </label>
                </div>
              </div>
            </div>

            {/* Portfolio */}
            <div className="bg-card rounded-2xl border border-border p-5 card-shadow">
              <div className="flex items-center justify-between mb-4 pb-2 border-b border-border">
                <h3 className="font-black text-foreground text-sm flex items-center gap-2">
                  <Images className="w-4 h-4 text-muted-foreground" />
                  Fotos de trabajos realizados
                </h3>
                <span className="text-xs text-muted-foreground">{portfolio.length} foto{portfolio.length !== 1 ? 's' : ''}</span>
              </div>

              {portfolio.length > 0 && (
                <div className="grid grid-cols-3 gap-2 mb-4">
                  {portfolio.map((url, i) => (
                    <div key={i} className="relative aspect-square group">
                      <img
                        src={url}
                        alt={`Trabajo ${i + 1}`}
                        className="w-full h-full object-cover rounded-xl cursor-pointer"
                        onClick={() => window.open(url, '_blank')}
                        onError={(e) => { e.currentTarget.src = 'https://placehold.co/120x120/e5e7eb/6b7280?text=Error'; }}
                      />
                      <button
                        onClick={() => removePortfolioPhoto(url)}
                        className="absolute -top-1.5 -right-1.5 w-6 h-6 bg-destructive text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity shadow-md"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              <label className={`flex items-center justify-center gap-2 w-full py-3 rounded-xl border-2 border-dashed cursor-pointer transition-all ${
                uploadingPortfolio
                  ? 'border-primary/40 bg-primary/5 text-primary'
                  : 'border-border hover:border-primary/50 hover:bg-muted text-muted-foreground hover:text-foreground'
              }`}>
                {uploadingPortfolio ? (
                  <>
                    <div className="w-4 h-4 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
                    <span className="text-sm font-semibold">Subiendo...</span>
                  </>
                ) : (
                  <>
                    <Plus className="w-4 h-4" />
                    <span className="text-sm font-semibold">Agregar fotos</span>
                  </>
                )}
                <input
                  ref={portfolioInputRef}
                  type="file"
                  accept="image/*"
                  multiple
                  className="hidden"
                  onChange={handlePortfolioUpload}
                  disabled={uploadingPortfolio}
                />
              </label>
              <p className="text-xs text-muted-foreground text-center mt-2">
                Tocá una foto para verla en grande. Pasá el cursor para eliminarla.
              </p>
            </div>

            {/* Payment info */}
            <div className="bg-card rounded-2xl border border-border p-5 card-shadow">
              <h3 className="font-black text-foreground mb-1 text-sm flex items-center gap-2">
                <CreditCard className="w-4 h-4 text-muted-foreground" />
                Datos de cobro
              </h3>
              <p className="text-xs text-muted-foreground mb-4 pb-3 border-b border-border">
                El cliente verá estos datos para transferirte cuando finalices un trabajo.
              </p>
              <div className="space-y-3">
                <label className="block">
                  <span className="text-sm font-bold text-foreground">Alias</span>
                  <input
                    type="text"
                    value={alias}
                    onChange={(e) => setAlias(e.target.value)}
                    placeholder="mi.alias.banco"
                    className="mt-1.5 w-full px-4 py-3 bg-muted border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary transition"
                  />
                </label>
                <label className="block">
                  <span className="text-sm font-bold text-foreground">CBU / CVU</span>
                  <input
                    type="text"
                    value={cbu}
                    onChange={(e) => { setCbu(e.target.value.replace(/\D/g, '')); setSaveError(''); }}
                    placeholder="0000000000000000000000"
                    maxLength={22}
                    className={`mt-1.5 w-full px-4 py-3 bg-muted border rounded-xl text-sm font-mono focus:outline-none focus:ring-2 focus:ring-primary transition ${
                      cbu.trim() && cbu.trim().length !== 22 ? 'border-destructive' : 'border-border'
                    }`}
                  />
                  {cbu.trim().length > 0 && cbu.trim().length !== 22 && (
                    <p className="text-xs text-destructive mt-1 font-semibold">
                      {cbu.trim().length}/22 dígitos
                    </p>
                  )}
                </label>

                {/* MercadoPago */}
                <div className="pt-1 border-t border-border">
                  <label className="block">
                    <div className="flex items-center gap-2 mb-1.5">
                      <MercadoPagoLogo className="w-5 h-5" />
                      <span className="text-sm font-bold text-foreground">Link de MercadoPago</span>
                      <span className="text-xs text-muted-foreground">(opcional)</span>
                    </div>
                    <input
                      type="url"
                      value={mpLink}
                      onChange={(e) => setMpLink(e.target.value)}
                      placeholder="https://mpago.la/..."
                      className="w-full px-4 py-3 bg-muted border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary transition"
                    />
                    <p className="text-xs text-muted-foreground mt-1.5">
                      Generá tu link de cobro en la app de MercadoPago y pegalo aquí.
                    </p>
                  </label>
                </div>
              </div>
            </div>
          </>
        )}

        {/* Logout */}
        <button
          onClick={signOut}
          className="w-full flex items-center justify-center gap-2 py-3.5 rounded-2xl border-2 border-border text-muted-foreground hover:border-destructive hover:text-destructive transition-all font-bold text-sm"
        >
          <LogOut className="w-4 h-4" />
          {t.logout}
        </button>
      </div>

      {/* Save bar */}
      <div className="fixed bottom-20 left-0 right-0 max-w-lg mx-auto px-4 z-10">
        {saveError && (
          <div className="mb-2 text-center text-sm font-bold text-destructive bg-destructive/10 border border-destructive/20 rounded-2xl py-2.5 px-4">
            {saveError}
          </div>
        )}
        {savedMsg && !saveError && (
          <div className="mb-2 text-center text-sm font-bold text-green-700 dark:text-green-400 bg-green-100 dark:bg-green-950/50 border border-green-200 dark:border-green-800 rounded-2xl py-2.5">
            {savedMsg}
          </div>
        )}
        <button
          onClick={handleSave}
          disabled={isSaving || uploadingPortfolio}
          className="w-full gradient-orange text-white font-black py-4 rounded-2xl shadow-xl glow-secondary hover:brightness-95 transition-all active:scale-[0.98] disabled:opacity-60 flex items-center justify-center gap-2"
        >
          {isSaving ? (
            <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
          ) : (
            <>
              <Save className="w-5 h-5" />
              {t.saveProfile}
            </>
          )}
        </button>
      </div>

      <BottomNav t={t} />
    </div>
  );
}
