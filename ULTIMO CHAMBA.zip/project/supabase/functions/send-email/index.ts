import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const FROM = "Chamba <no-reply@chamba.app>";
const RESEND_API = "https://api.resend.com/emails";

type EmailType = "job_request" | "quote_sent" | "job_finished" | "job_completed";

interface Payload {
  type: EmailType;
  to: string;
  data: Record<string, string | number | null | undefined>;
}

function buildEmail(type: EmailType, data: Record<string, string | number | null | undefined>): { subject: string; html: string } {
  const brand = `
    <div style="background:linear-gradient(135deg,#0d9488,#f97316);padding:28px 32px;border-radius:16px 16px 0 0;">
      <h1 style="margin:0;color:#fff;font-size:22px;font-weight:900;letter-spacing:-0.5px;">Chamba</h1>
      <p style="margin:4px 0 0;color:rgba(255,255,255,0.8);font-size:13px;">La plataforma de trabajos</p>
    </div>
  `;
  const footer = `
    <div style="padding:20px 32px;background:#f8fafc;border-radius:0 0 16px 16px;border-top:1px solid #e2e8f0;">
      <p style="margin:0;font-size:12px;color:#94a3b8;text-align:center;">
        Este email fue enviado automáticamente por Chamba. No respondas a este mensaje.
      </p>
    </div>
  `;

  const wrap = (content: string) => `
    <div style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;max-width:520px;margin:0 auto;background:#fff;border-radius:16px;box-shadow:0 4px 24px rgba(0,0,0,0.08);overflow:hidden;">
      ${brand}
      <div style="padding:28px 32px;">
        ${content}
      </div>
      ${footer}
    </div>
  `;

  if (type === "job_request") {
    return {
      subject: `Nueva solicitud de trabajo — ${data.service}`,
      html: wrap(`
        <h2 style="margin:0 0 6px;color:#0f172a;font-size:18px;font-weight:900;">Recibiste una nueva solicitud</h2>
        <p style="margin:0 0 20px;color:#64748b;font-size:14px;">Un cliente quiere contratarte para <strong style="color:#0d9488;">${data.service}</strong>.</p>

        <div style="background:#f0fdf9;border:1px solid #99f6e4;border-radius:12px;padding:16px 20px;margin-bottom:20px;">
          <p style="margin:0 0 8px;font-size:12px;font-weight:700;color:#0d9488;text-transform:uppercase;letter-spacing:0.5px;">Descripción del trabajo</p>
          <p style="margin:0;font-size:14px;color:#0f172a;line-height:1.6;">${data.description || "Sin descripción adicional."}</p>
        </div>

        <table style="width:100%;border-collapse:collapse;margin-bottom:24px;">
          <tr><td style="padding:8px 0;border-bottom:1px solid #f1f5f9;font-size:13px;color:#64748b;width:40%;">Cliente</td><td style="padding:8px 0;border-bottom:1px solid #f1f5f9;font-size:13px;font-weight:600;color:#0f172a;">${data.client_name || data.client_email}</td></tr>
          <tr><td style="padding:8px 0;border-bottom:1px solid #f1f5f9;font-size:13px;color:#64748b;">Email</td><td style="padding:8px 0;border-bottom:1px solid #f1f5f9;font-size:13px;font-weight:600;color:#0f172a;">${data.client_email}</td></tr>
          <tr><td style="padding:8px 0;font-size:13px;color:#64748b;">Método de pago</td><td style="padding:8px 0;font-size:13px;font-weight:600;color:#0f172a;">${data.payment_method === "cash" ? "Efectivo" : "Transferencia bancaria"}</td></tr>
        </table>

        <div style="background:#fff7ed;border:1px solid #fed7aa;border-radius:12px;padding:14px 18px;">
          <p style="margin:0;font-size:13px;color:#c2410c;font-weight:600;">Ingresá a tu dashboard para enviar el presupuesto al cliente.</p>
        </div>
      `),
    };
  }

  if (type === "quote_sent") {
    const hasDeposit = data.deposit_amount && Number(data.deposit_amount) > 0;
    return {
      subject: `Tu presupuesto llegó — ${data.service}`,
      html: wrap(`
        <h2 style="margin:0 0 6px;color:#0f172a;font-size:18px;font-weight:900;">Recibiste un presupuesto</h2>
        <p style="margin:0 0 20px;color:#64748b;font-size:14px;"><strong style="color:#0f172a;">${data.worker_name}</strong> te envió un presupuesto para <strong style="color:#0d9488;">${data.service}</strong>.</p>

        <div style="background:linear-gradient(135deg,#f0fdf9,#ecfeff);border:1px solid #99f6e4;border-radius:12px;padding:20px;margin-bottom:20px;text-align:center;">
          <p style="margin:0 0 4px;font-size:12px;color:#64748b;font-weight:600;text-transform:uppercase;letter-spacing:0.5px;">Total del trabajo</p>
          <p style="margin:0;font-size:36px;font-weight:900;color:#0d9488;">${data.currency || "ARS"} ${Number(data.amount || 0).toLocaleString("es-AR")}</p>
          ${hasDeposit ? `<p style="margin:8px 0 0;font-size:13px;color:#f97316;font-weight:700;">Seña requerida: ${data.currency || "ARS"} ${Number(data.deposit_amount).toLocaleString("es-AR")}</p>` : ""}
        </div>

        ${data.notes ? `
        <div style="background:#f8fafc;border-radius:12px;padding:16px 20px;margin-bottom:20px;">
          <p style="margin:0 0 6px;font-size:12px;font-weight:700;color:#475569;text-transform:uppercase;letter-spacing:0.5px;">Nota del trabajador</p>
          <p style="margin:0;font-size:14px;color:#0f172a;line-height:1.6;">${data.notes}</p>
        </div>` : ""}

        <div style="background:#fefce8;border:1px solid #fde68a;border-radius:12px;padding:14px 18px;">
          <p style="margin:0;font-size:13px;color:#92400e;font-weight:600;">Ingresá a "Mis trabajos" en Chamba para aceptar o rechazar el presupuesto.</p>
        </div>
      `),
    };
  }

  if (type === "job_finished") {
    return {
      subject: `El trabajo terminó — realizá el pago a ${data.worker_name}`,
      html: wrap(`
        <h2 style="margin:0 0 6px;color:#0f172a;font-size:18px;font-weight:900;">El trabajo fue completado</h2>
        <p style="margin:0 0 20px;color:#64748b;font-size:14px;"><strong style="color:#0f172a;">${data.worker_name}</strong> marcó el trabajo de <strong style="color:#0d9488;">${data.service}</strong> como finalizado.</p>

        <div style="background:linear-gradient(135deg,#f0fdf9,#ecfeff);border:1px solid #99f6e4;border-radius:12px;padding:20px;margin-bottom:20px;text-align:center;">
          <p style="margin:0 0 4px;font-size:12px;color:#64748b;font-weight:600;text-transform:uppercase;letter-spacing:0.5px;">Monto a pagar</p>
          <p style="margin:0;font-size:36px;font-weight:900;color:#0d9488;">${data.currency || "ARS"} ${Number(data.amount || 0).toLocaleString("es-AR")}</p>
        </div>

        ${data.payment_info ? `
        <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:12px;padding:16px 20px;margin-bottom:20px;">
          <p style="margin:0 0 6px;font-size:12px;font-weight:700;color:#475569;text-transform:uppercase;letter-spacing:0.5px;">Datos de cobro del trabajador</p>
          <p style="margin:0;font-size:14px;color:#0f172a;font-weight:600;line-height:1.6;">${data.payment_info}</p>
        </div>` : ""}

        <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:12px;padding:14px 18px;">
          <p style="margin:0;font-size:13px;color:#166534;font-weight:600;">Una vez que realices el pago, marcá el trabajo como completado en la app.</p>
        </div>
      `),
    };
  }

  // job_completed
  return {
    subject: `Pago recibido — ${data.service}`,
    html: wrap(`
      <h2 style="margin:0 0 6px;color:#0f172a;font-size:18px;font-weight:900;">¡Cobro confirmado!</h2>
      <p style="margin:0 0 20px;color:#64748b;font-size:14px;">El cliente <strong style="color:#0f172a;">${data.client_name || data.client_email}</strong> confirmó el pago por <strong style="color:#0d9488;">${data.service}</strong>.</p>

      <div style="background:linear-gradient(135deg,#f0fdf9,#ecfeff);border:1px solid #99f6e4;border-radius:12px;padding:20px;margin-bottom:20px;text-align:center;">
        <p style="margin:0 0 4px;font-size:12px;color:#64748b;font-weight:600;text-transform:uppercase;letter-spacing:0.5px;">Monto cobrado</p>
        <p style="margin:0;font-size:36px;font-weight:900;color:#0d9488;">${data.currency || "ARS"} ${Number(data.amount || 0).toLocaleString("es-AR")}</p>
      </div>

      <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:12px;padding:14px 18px;">
        <p style="margin:0;font-size:13px;color:#166534;font-weight:600;">El trabajo quedó registrado como completado. ¡Gracias por usar Chamba!</p>
      </div>
    `),
  };
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const apiKey = Deno.env.get("RESEND_API_KEY");
    if (!apiKey) {
      return new Response(
        JSON.stringify({ error: "RESEND_API_KEY not configured" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    const payload: Payload = await req.json();
    const { type, to, data } = payload;

    if (!type || !to) {
      return new Response(
        JSON.stringify({ error: "Missing required fields: type, to" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    const { subject, html } = buildEmail(type, data || {});

    const res = await fetch(RESEND_API, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ from: FROM, to, subject, html }),
    });

    if (!res.ok) {
      const err = await res.text();
      return new Response(
        JSON.stringify({ error: "Resend API error", details: err }),
        { status: res.status, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    const result = await res.json();
    return new Response(
      JSON.stringify({ ok: true, id: result.id }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: (err as Error).message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});
