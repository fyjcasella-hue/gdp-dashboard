-- Add payment info fields to workers table
ALTER TABLE workers ADD COLUMN IF NOT EXISTS alias TEXT;
ALTER TABLE workers ADD COLUMN IF NOT EXISTS cbu TEXT;
ALTER TABLE workers ADD COLUMN IF NOT EXISTS zone_province TEXT;

-- Expand job status check to include 'finished' (worker done, awaiting client payment)
ALTER TABLE jobs DROP CONSTRAINT IF EXISTS jobs_status_check;
ALTER TABLE jobs ADD CONSTRAINT jobs_status_check
  CHECK (status IN ('pending', 'accepted', 'in_progress', 'finished', 'completed', 'cancelled', 'disputed'));
