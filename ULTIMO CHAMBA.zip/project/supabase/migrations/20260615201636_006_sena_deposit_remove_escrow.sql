-- Add deposit (seña) fields to quotes
ALTER TABLE quotes ADD COLUMN IF NOT EXISTS sena_amount NUMERIC DEFAULT NULL;

-- Add deposit tracking to jobs
ALTER TABLE jobs ADD COLUMN IF NOT EXISTS sena_amount NUMERIC DEFAULT NULL;
ALTER TABLE jobs ADD COLUMN IF NOT EXISTS sena_paid BOOLEAN NOT NULL DEFAULT FALSE;
