-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Profiles table (extends auth.users with role)
CREATE TABLE profiles (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE UNIQUE NOT NULL,
  email TEXT NOT NULL,
  full_name TEXT,
  avatar TEXT,
  role TEXT DEFAULT 'client' CHECK (role IN ('client', 'worker')),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Workers table (worker profiles with services)
CREATE TABLE workers (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  user_email TEXT NOT NULL,
  name TEXT NOT NULL,
  bio TEXT,
  service TEXT NOT NULL,
  avatar TEXT,
  zone_country TEXT,
  zone_province TEXT,
  zone_locality TEXT,
  lat DOUBLE PRECISION,
  lng DOUBLE PRECISION,
  price_range TEXT DEFAULT '$$',
  rating DOUBLE PRECISION DEFAULT 5.0,
  review_count INTEGER DEFAULT 0,
  available BOOLEAN DEFAULT true,
  portfolio TEXT[] DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Jobs table (work requests)
CREATE TABLE jobs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  client_email TEXT NOT NULL,
  client_name TEXT,
  worker_id UUID REFERENCES workers(id) ON DELETE SET NULL,
  worker_name TEXT,
  service TEXT NOT NULL,
  description TEXT,
  amount DOUBLE PRECISION,
  currency TEXT DEFAULT 'USD',
  payment_method TEXT DEFAULT 'card',
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'in_progress', 'completed', 'cancelled', 'disputed')),
  payment_status TEXT DEFAULT 'unpaid' CHECK (payment_status IN ('unpaid', 'escrowed', 'released', 'refunded')),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Chat messages table
CREATE TABLE chat_messages (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  chat_id TEXT NOT NULL,
  worker_id UUID,
  sender_email TEXT NOT NULL,
  text TEXT,
  image_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Reviews table
CREATE TABLE reviews (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  worker_id UUID REFERENCES workers(id) ON DELETE CASCADE NOT NULL,
  job_id UUID REFERENCES jobs(id) ON DELETE SET NULL,
  client_email TEXT NOT NULL,
  client_name TEXT,
  rating INTEGER CHECK (rating >= 1 AND rating <= 5) NOT NULL,
  comment TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS on all tables
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE workers ENABLE ROW LEVEL SECURITY;
ALTER TABLE jobs ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;

-- Profiles policies
CREATE POLICY "profiles_select_own" ON profiles FOR SELECT
  TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "profiles_insert_own" ON profiles FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "profiles_update_own" ON profiles FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- Workers policies (public read, own write)
CREATE POLICY "workers_select_all" ON workers FOR SELECT
  TO authenticated USING (true);
CREATE POLICY "workers_insert_own" ON workers FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "workers_update_own" ON workers FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- Jobs policies
CREATE POLICY "jobs_select_own" ON jobs FOR SELECT
  TO authenticated USING (client_email = auth.jwt() ->> 'email' OR auth.uid()::text IN (SELECT user_id::text FROM workers WHERE workers.id = jobs.worker_id));
CREATE POLICY "jobs_insert_own" ON jobs FOR INSERT
  TO authenticated WITH CHECK (client_email = auth.jwt() ->> 'email');
CREATE POLICY "jobs_update_own" ON jobs FOR UPDATE
  TO authenticated USING (client_email = auth.jwt() ->> 'email');

-- Chat messages policies
CREATE POLICY "chat_select_participant" ON chat_messages FOR SELECT
  TO authenticated USING (sender_email = auth.jwt() ->> 'email');
CREATE POLICY "chat_insert_participant" ON chat_messages FOR INSERT
  TO authenticated WITH CHECK (sender_email = auth.jwt() ->> 'email');

-- Reviews policies
CREATE POLICY "reviews_select_all" ON reviews FOR SELECT
  TO authenticated USING (true);
CREATE POLICY "reviews_insert_own" ON reviews FOR INSERT
  TO authenticated WITH CHECK (client_email = auth.jwt() ->> 'email');

-- Create indexes for performance
CREATE INDEX idx_workers_service ON workers(service);
CREATE INDEX idx_workers_location ON workers(zone_country, zone_locality);
CREATE INDEX idx_jobs_client ON jobs(client_email);
CREATE INDEX idx_jobs_worker ON jobs(worker_id);
CREATE INDEX idx_reviews_worker ON reviews(worker_id);
CREATE INDEX idx_chat_chat_id ON chat_messages(chat_id);

-- Function to update timestamps
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply triggers for updated_at
CREATE TRIGGER profiles_updated_at BEFORE UPDATE ON profiles FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER workers_updated_at BEFORE UPDATE ON workers FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER jobs_updated_at BEFORE UPDATE ON jobs FOR EACH ROW EXECUTE FUNCTION update_updated_at();