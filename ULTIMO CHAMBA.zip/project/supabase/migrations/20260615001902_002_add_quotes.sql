
CREATE TABLE IF NOT EXISTS quotes (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  job_id UUID REFERENCES jobs(id) ON DELETE CASCADE NOT NULL,
  worker_id UUID REFERENCES workers(id) ON DELETE CASCADE NOT NULL,
  worker_name TEXT NOT NULL,
  amount DECIMAL(12,2) NOT NULL,
  currency TEXT NOT NULL DEFAULT 'ARS',
  message TEXT,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'rejected')),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS quotes_job_id_idx ON quotes(job_id);
CREATE INDEX IF NOT EXISTS quotes_worker_id_idx ON quotes(worker_id);

ALTER TABLE quotes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "read_quotes" ON quotes FOR SELECT
  TO authenticated
  USING (
    worker_id IN (SELECT id FROM workers WHERE user_email = auth.jwt() ->> 'email')
    OR
    job_id IN (SELECT id FROM jobs WHERE client_email = auth.jwt() ->> 'email')
  );

CREATE POLICY "workers_insert_quotes" ON quotes FOR INSERT
  TO authenticated
  WITH CHECK (
    worker_id IN (SELECT id FROM workers WHERE user_email = auth.jwt() ->> 'email')
  );

CREATE POLICY "clients_update_quotes" ON quotes FOR UPDATE
  TO authenticated
  USING (
    job_id IN (SELECT id FROM jobs WHERE client_email = auth.jwt() ->> 'email')
  )
  WITH CHECK (
    job_id IN (SELECT id FROM jobs WHERE client_email = auth.jwt() ->> 'email')
  );

CREATE POLICY "no_delete_quotes" ON quotes FOR DELETE
  TO authenticated
  USING (false);
