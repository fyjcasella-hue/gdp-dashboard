-- Add services array column to workers
ALTER TABLE workers ADD COLUMN IF NOT EXISTS services text[] NOT NULL DEFAULT '{}';

-- Migrate existing single service to array (only where services is still empty)
UPDATE workers
SET services = ARRAY[service]
WHERE services = '{}' AND service IS NOT NULL AND service != '';

-- Index for efficient array containment queries
CREATE INDEX IF NOT EXISTS idx_workers_services ON workers USING GIN (services);
