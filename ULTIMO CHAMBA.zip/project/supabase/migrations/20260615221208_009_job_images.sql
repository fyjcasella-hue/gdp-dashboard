-- Add images array to jobs table
ALTER TABLE jobs ADD COLUMN IF NOT EXISTS images TEXT[] DEFAULT '{}';

-- Create public storage bucket for job images
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'job-images',
  'job-images',
  true,
  10485760,
  ARRAY['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/heic']
)
ON CONFLICT (id) DO NOTHING;

-- Storage RLS policies
CREATE POLICY "job_images_select" ON storage.objects FOR SELECT
  TO authenticated USING (bucket_id = 'job-images');

CREATE POLICY "job_images_insert" ON storage.objects FOR INSERT
  TO authenticated WITH CHECK (bucket_id = 'job-images');

CREATE POLICY "job_images_delete_own" ON storage.objects FOR DELETE
  TO authenticated USING (bucket_id = 'job-images' AND auth.uid()::text = (storage.foldername(name))[1]);
